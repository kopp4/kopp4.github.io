(function(g) {
    var window = this;
    'use strict';
    var dZa = function(a, b) {
            a.Qa("onAutonavCoundownStarted", b)
        },
        c5 = function(a, b, c) {
            g.M(a.element, "ytp-suggestion-set", !!b.videoId);
            var d = b.playlistId;
            c = b.Te(c ? c : "mqdefault.jpg");
            var e = null,
                f = null;
            b instanceof g.UD && (b.lengthText ? (e = b.lengthText || null, f = b.Jq || null) : b.lengthSeconds && (e = g.RJ(b.lengthSeconds), f = g.RJ(b.lengthSeconds, !0)));
            var k = !!d;
            d = k && "RD" === g.QD(d).type;
            var l = b instanceof g.UD ? b.isLivePlayback : null,
                m = b instanceof g.UD ? b.isUpcoming : null;
            c = {
                title: b.title,
                author: b.author,
                author_and_views: b.shortViewCount ? b.author + " \u2022 " + b.shortViewCount : b.author,
                aria_label: b.cm || g.qG("Watch $TITLE", {
                    TITLE: b.title
                }),
                duration: e,
                timestamp: f,
                url: b.fl(),
                is_live: l,
                is_upcoming: m,
                is_list: k,
                is_mix: d,
                background: c ? "background-image: url(" + c + ")" : "",
                views_and_publish_time: b.shortViewCount ? b.shortViewCount + " \u2022 " + b.publishedTimeText : b.publishedTimeText,
                autoplayAlternativeHeader: b.Jn
            };
            b instanceof g.TD && (c.playlist_length = b.playlistLength);
            a.update(c)
        },
        d5 = function(a) {
            var b = a.V(),
                c = b.j;
            g.W.call(this, {
                G: "a",
                L: "ytp-autonav-suggestion-card",
                W: {
                    href: "{{url}}",
                    target: c ? b.J : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                U: [{
                    G: "div",
                    Ha: ["ytp-autonav-endscreen-upnext-thumbnail", "ytp-autonav-thumbnail-small"],
                    W: {
                        style: "{{background}}"
                    },
                    U: [{
                        G: "div",
                        W: {
                            "aria-label": "{{timestamp}}"
                        },
                        Ha: ["ytp-autonav-timestamp"],
                        qa: "{{duration}}"
                    }, {
                        G: "div",
                        Ha: ["ytp-autonav-live-stamp"],
                        qa: "Live"
                    }, {
                        G: "div",
                        Ha: ["ytp-autonav-upcoming-stamp"],
                        qa: "Upcoming"
                    }, {
                        G: "div",
                        L: "ytp-autonav-list-overlay",
                        U: [{
                            G: "div",
                            L: "ytp-autonav-mix-text",
                            qa: "Mix"
                        }, {
                            G: "div",
                            L: "ytp-autonav-mix-icon"
                        }]
                    }]
                }, {
                    G: "div",
                    Ha: ["ytp-autonav-endscreen-upnext-title", "ytp-autonav-title-card"],
                    qa: "{{title}}"
                }, {
                    G: "div",
                    Ha: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-author-card"],
                    qa: "{{author}}"
                }, {
                    G: "div",
                    Ha: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-view-and-date-card"],
                    qa: "{{views_and_publish_time}}"
                }]
            });
            this.I = a;
            this.suggestion =
                null;
            this.j = c;
            this.Pa("click", this.onClick);
            this.Pa("keypress", this.onKeyPress)
        },
        f5 = function(a, b) {
            b = void 0 === b ? !1 : b;
            g.W.call(this, {
                G: "div",
                L: "ytp-autonav-endscreen-countdown-container"
            });
            var c = this;
            this.J = b;
            this.D = void 0;
            this.u = 0;
            b = a.V();
            var d = b.j;
            this.I = a;
            this.suggestion = null;
            this.onVideoDataChange("newdata", this.I.getVideoData());
            this.T(a, "videodatachange", this.onVideoDataChange);
            this.j = new g.W({
                G: "div",
                L: "ytp-autonav-endscreen-upnext-container",
                W: {
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                U: [{
                    G: "div",
                    L: "ytp-autonav-endscreen-upnext-header"
                }, {
                    G: "div",
                    L: "ytp-autonav-endscreen-upnext-alternative-header",
                    qa: "{{autoplayAlternativeHeader}}"
                }, {
                    G: "a",
                    L: "ytp-autonav-endscreen-link-container",
                    W: {
                        href: "{{url}}",
                        target: d ? b.J : ""
                    },
                    U: [{
                            G: "div",
                            L: "ytp-autonav-endscreen-upnext-thumbnail",
                            W: {
                                style: "{{background}}"
                            },
                            U: [{
                                G: "div",
                                W: {
                                    "aria-label": "{{timestamp}}"
                                },
                                Ha: ["ytp-autonav-timestamp"],
                                qa: "{{duration}}"
                            }, {
                                G: "div",
                                Ha: ["ytp-autonav-live-stamp"],
                                qa: "Live"
                            }, {
                                G: "div",
                                Ha: ["ytp-autonav-upcoming-stamp"],
                                qa: "Upcoming"
                            }]
                        },
                        {
                            G: "div",
                            L: "ytp-autonav-endscreen-video-info",
                            U: [{
                                G: "div",
                                L: "ytp-autonav-endscreen-premium-badge"
                            }, {
                                G: "div",
                                L: "ytp-autonav-endscreen-upnext-title",
                                qa: "{{title}}"
                            }, {
                                G: "div",
                                L: "ytp-autonav-endscreen-upnext-author",
                                qa: "{{author}}"
                            }, {
                                G: "div",
                                L: "ytp-autonav-view-and-date",
                                qa: "{{views_and_publish_time}}"
                            }, {
                                G: "div",
                                L: "ytp-autonav-author-and-view",
                                qa: "{{author_and_views}}"
                            }]
                        }
                    ]
                }]
            });
            g.K(this, this.j);
            this.j.Ba(this.element);
            d || this.T(this.j.Da("ytp-autonav-endscreen-link-container"), "click", this.PJ);
            this.I.Cb(this.element,
                this, 115127);
            this.I.Cb(this.j.Da("ytp-autonav-endscreen-link-container"), this, 115128);
            this.overlay = new g.W({
                G: "div",
                L: "ytp-autonav-overlay"
            });
            g.K(this, this.overlay);
            this.overlay.Ba(this.element);
            this.B = new g.W({
                G: "div",
                L: "ytp-autonav-endscreen-button-container"
            });
            g.K(this, this.B);
            this.B.Ba(this.element);
            this.cancelButton = new g.W({
                G: "button",
                Ha: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-cancel-button"],
                W: {
                    "aria-label": "Cancel autoplay"
                },
                qa: "Cancel"
            });
            g.K(this, this.cancelButton);
            this.cancelButton.Ba(this.B.element);
            this.cancelButton.Pa("click", this.oS, this);
            this.I.Cb(this.cancelButton.element, this, 115129);
            this.playButton = new g.W({
                G: "a",
                Ha: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-play-button"],
                W: {
                    href: "{{url}}",
                    role: "button",
                    "aria-label": "Play next video"
                },
                qa: "Play Now"
            });
            g.K(this, this.playButton);
            this.playButton.Ba(this.B.element);
            this.playButton.Pa("click", this.PJ, this);
            this.I.Cb(this.playButton.element, this, 115130);
            this.C = new g.L(function() {
                    e5(c)
                },
                500);
            g.K(this, this.C);
            this.OJ();
            this.T(a, "autonavvisibility", this.OJ)
        },
        i5 = function(a) {
            var b = a.I.Jj(!0, a.I.isFullscreen());
            g.M(a.element, "ytp-autonav-endscreen-small-mode", a.Ef(b));
            g.M(a.element, "ytp-autonav-endscreen-is-premium", !!a.suggestion && !!a.suggestion.hC);
            g.M(a.I.getRootNode(), "ytp-autonav-endscreen-cancelled-state", !a.I.ze());
            g.M(a.I.getRootNode(), "countdown-running", a.Qh());
            g.M(a.element, "ytp-player-content", a.I.ze());
            g.Qm(a.overlay.element, {
                width: b.width + "px"
            });
            if (!a.Qh()) {
                a.I.ze() ? g5(a, Math.round(h5(a) / 1E3)) : g5(a);
                b = !!a.suggestion && !!a.suggestion.Jn;
                var c = a.I.ze() || !b;
                g.M(a.element, "ytp-autonav-endscreen-upnext-alternative-header-only", !c && b);
                g.M(a.element, "ytp-autonav-endscreen-upnext-no-alternative-header", c && !b);
                g.SI(a.B, a.I.ze())
            }
        },
        e5 = function(a) {
            var b = h5(a),
                c = Math,
                d = c.min;
            var e = a.u ? Date.now() - a.u : 0;
            c = d.call(c, e, b);
            g5(a, Math.ceil((b - c) / 1E3));
            500 >= b - c && a.Qh() ? a.select(!0) : a.Qh() && a.C.start()
        },
        h5 = function(a) {
            var b = a.I.mq();
            return 0 <= b ? b : g.TB(a.I.V().experiments, "autoplay_time") || 1E4
        },
        g5 = function(a, b) {
            b = void 0 === b ? -1 : b;
            a = a.j.Da("ytp-autonav-endscreen-upnext-header");
            g.ri(a);
            if (0 <= b) {
                b = String(b);
                var c = "Up next in $SECONDS".match(RegExp("\\$SECONDS", "gi"))[0],
                    d = "Up next in $SECONDS".indexOf(c);
                if (0 <= d) {
                    a.appendChild(g.qi("Up next in $SECONDS".slice(0, d)));
                    var e = g.pi("span");
                    g.Dp(e, "ytp-autonav-endscreen-upnext-header-countdown-number");
                    g.wi(e, b);
                    a.appendChild(e);
                    a.appendChild(g.qi("Up next in $SECONDS".slice(d + c.length)));
                    return
                }
            }
            g.wi(a, "Up next")
        },
        j5 = function(a, b) {
            g.W.call(this, {
                G: "div",
                Ha: ["html5-endscreen", "ytp-player-content", b || "base-endscreen"]
            });
            this.created = !1;
            this.player = a
        },
        k5 = function(a) {
            g.W.call(this, {
                G: "div",
                Ha: ["ytp-upnext", "ytp-player-content"],
                W: {
                    "aria-label": "{{aria_label}}"
                },
                U: [{
                    G: "div",
                    L: "ytp-cued-thumbnail-overlay-image",
                    W: {
                        style: "{{background}}"
                    }
                }, {
                    G: "span",
                    L: "ytp-upnext-top",
                    U: [{
                        G: "span",
                        L: "ytp-upnext-header",
                        qa: "Up Next"
                    }, {
                        G: "span",
                        L: "ytp-upnext-title",
                        qa: "{{title}}"
                    }, {
                        G: "span",
                        L: "ytp-upnext-author",
                        qa: "{{author}}"
                    }]
                }, {
                    G: "a",
                    L: "ytp-upnext-autoplay-icon",
                    W: {
                        role: "button",
                        href: "{{url}}",
                        "aria-label": "Play next video"
                    },
                    U: [{
                        G: "svg",
                        W: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        U: [{
                            G: "circle",
                            L: "ytp-svg-autoplay-circle",
                            W: {
                                cx: "36",
                                cy: "36",
                                fill: "#fff",
                                "fill-opacity": "0.3",
                                r: "31.5"
                            }
                        }, {
                            G: "circle",
                            L: "ytp-svg-autoplay-ring",
                            W: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            G: "path",
                            L: "ytp-svg-fill",
                            W: {
                                d: "M 24,48 41,36 24,24 V 48 z M 44,24 v 24 h 4 V 24 h -4 z"
                            }
                        }]
                    }]
                }, {
                    G: "span",
                    L: "ytp-upnext-bottom",
                    U: [{
                        G: "span",
                        L: "ytp-upnext-cancel"
                    }, {
                        G: "span",
                        L: "ytp-upnext-paused",
                        qa: "Autoplay is paused"
                    }]
                }]
            });
            this.api = a;
            this.cancelButton = null;
            this.D = this.Da("ytp-svg-autoplay-ring");
            this.B = this.notification = this.j = this.suggestion = null;
            this.C = new g.L(this.Kz, 5E3, this);
            this.u = 0;
            var b = this.Da("ytp-upnext-cancel");
            this.cancelButton = new g.W({
                G: "button",
                Ha: ["ytp-upnext-cancel-button", "ytp-button"],
                W: {
                    tabindex: "0",
                    "aria-label": "Cancel autoplay"
                },
                qa: "Cancel"
            });
            g.K(this, this.cancelButton);
            this.cancelButton.Pa("click", this.pS, this);
            this.cancelButton.Ba(b);
            this.cancelButton && this.api.Cb(this.cancelButton.element,
                this, 115129);
            g.K(this, this.C);
            this.api.Cb(this.element, this, 18788);
            b = this.Da("ytp-upnext-autoplay-icon");
            this.T(b, "click", this.qS);
            this.api.Cb(b, this, 115130);
            this.QJ();
            this.T(a, "autonavvisibility", this.QJ);
            this.T(a, "mdxnowautoplaying", this.nX);
            this.T(a, "mdxautoplaycanceled", this.oX);
            g.M(this.element, "ytp-upnext-mobile", this.api.V().isMobile)
        },
        eZa = function(a, b) {
            return b ? b : 0 <= a.api.mq() ? a.api.mq() : g.TB(a.api.V().experiments, "autoplay_time") || 1E4
        },
        l5 = function(a, b) {
            b = eZa(a, b);
            var c = Math,
                d = c.min;
            var e = (0, g.Q)() - a.u;
            c = d.call(c, e, b);
            b = 0 === b ? 1 : Math.min(c / b, 1);
            a.D.setAttribute("stroke-dashoffset", "" + -211 * (b + 1));
            1 <= b && a.Qh() && 3 !== a.api.getPresentingPlayerType() ? a.select(!0) : a.Qh() && a.j.start()
        },
        m5 = function(a) {
            j5.call(this, a, "autonav-endscreen");
            this.overlay = this.videoData = null;
            this.table = new g.W({
                G: "div",
                L: "ytp-suggestion-panel",
                U: [{
                    G: "div",
                    Ha: ["ytp-autonav-endscreen-upnext-header", "ytp-autonav-endscreen-more-videos"],
                    qa: "More videos"
                }]
            });
            this.K = new g.W({
                G: "div",
                L: "ytp-suggestions-container"
            });
            this.videos = [];
            this.B = null;
            this.D = this.J = !1;
            this.u = new f5(this.player);
            g.K(this, this.u);
            this.u.Ba(this.element);
            a.getVideoData().lc ? this.j = this.u : (this.j = new k5(a), g.fM(this.player, this.j.element, 4), g.K(this, this.j));
            this.overlay = new g.W({
                G: "div",
                L: "ytp-autonav-overlay-cancelled-state"
            });
            g.K(this, this.overlay);
            this.overlay.Ba(this.element);
            this.C = new g.KA(this);
            g.K(this, this.C);
            g.K(this, this.table);
            this.table.Ba(this.element);
            this.table.show();
            g.K(this, this.K);
            this.K.Ba(this.table.element);
            this.hide()
        },
        n5 = function(a) {
            var b = a.ze();
            b !== a.D && (a.D = b, a.player.ea("autonavvisibility"), a.D ? (a.u !== a.j && a.u.hide(), a.table.hide()) : (a.u !== a.j && a.u.show(), a.table.show()))
        },
        o5 = function(a) {
            j5.call(this, a, "subscribecard-endscreen");
            this.j = new g.W({
                G: "div",
                L: "ytp-subscribe-card",
                U: [{
                    G: "img",
                    L: "ytp-author-image",
                    W: {
                        src: "{{profilePicture}}"
                    }
                }, {
                    G: "div",
                    L: "ytp-subscribe-card-right",
                    U: [{
                        G: "div",
                        L: "ytp-author-name",
                        qa: "{{author}}"
                    }, {
                        G: "div",
                        L: "html5-subscribe-button-container"
                    }]
                }]
            });
            g.K(this, this.j);
            this.j.Ba(this.element);
            var b = a.getVideoData();
            this.subscribeButton = new g.yN("Subscribe", null, "Unsubscribe", null, !0, !1, b.sj, b.subscribed, "trailer-endscreen", null, null, a);
            g.K(this, this.subscribeButton);
            this.subscribeButton.Ba(this.j.Da("html5-subscribe-button-container"));
            this.T(a, "videodatachange", this.Ka);
            this.Ka();
            this.hide()
        },
        p5 = function(a) {
            var b = a.V(),
                c = g.OA || g.YC ? {
                    style: "will-change: opacity"
                } : void 0,
                d = b.j,
                e = ["ytp-videowall-still"];
            b.isMobile && e.push("ytp-videowall-show-text");
            g.W.call(this, {
                G: "a",
                Ha: e,
                W: {
                    href: "{{url}}",
                    target: d ? b.J : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}"
                },
                U: [{
                    G: "div",
                    L: "ytp-videowall-still-image",
                    W: {
                        style: "{{background}}"
                    }
                }, {
                    G: "span",
                    L: "ytp-videowall-still-info",
                    U: [{
                        G: "span",
                        L: "ytp-videowall-still-info-bg",
                        U: [{
                            G: "span",
                            L: "ytp-videowall-still-info-content",
                            W: c,
                            U: [{
                                G: "span",
                                L: "ytp-videowall-still-info-title",
                                qa: "{{title}}"
                            }, {
                                G: "span",
                                L: "ytp-videowall-still-info-author",
                                qa: "{{author_and_views}}"
                            }, {
                                G: "span",
                                L: "ytp-videowall-still-info-live",
                                qa: "Live"
                            }, {
                                G: "span",
                                L: "ytp-videowall-still-info-duration",
                                qa: "{{duration}}"
                            }]
                        }]
                    }]
                }, {
                    G: "span",
                    Ha: ["ytp-videowall-still-listlabel-regular", "ytp-videowall-still-listlabel"],
                    U: [{
                        G: "span",
                        L: "ytp-videowall-still-listlabel-icon"
                    }, "Playlist", {
                        G: "span",
                        L: "ytp-videowall-still-listlabel-length",
                        U: [" (", {
                            G: "span",
                            qa: "{{playlist_length}}"
                        }, ")"]
                    }]
                }, {
                    G: "span",
                    Ha: ["ytp-videowall-still-listlabel-mix", "ytp-videowall-still-listlabel"],
                    U: [{
                        G: "span",
                        L: "ytp-videowall-still-listlabel-mix-icon"
                    }, "Mix", {
                        G: "span",
                        L: "ytp-videowall-still-listlabel-length",
                        qa: " (50+)"
                    }]
                }]
            });
            this.suggestion = null;
            this.u = d;
            this.api = a;
            this.j = new g.KA(this);
            g.K(this, this.j);
            this.Pa("click", this.onClick);
            this.Pa("keypress", this.onKeyPress);
            this.j.T(a, "videodatachange", this.onVideoDataChange);
            a.Zg(this.element, this);
            this.onVideoDataChange()
        },
        q5 = function(a) {
            j5.call(this, a, "videowall-endscreen");
            var b = this;
            this.I = a;
            this.B = 0;
            this.stills = [];
            this.C = this.videoData = null;
            this.D = this.K = !1;
            this.N = null;
            this.u = new g.KA(this);
            g.K(this, this.u);
            this.J = new g.L(function() {
                g.Fp(b.element, "ytp-show-tiles")
            }, 0);
            g.K(this, this.J);
            var c = new g.W({
                G: "button",
                Ha: ["ytp-button", "ytp-endscreen-previous"],
                W: {
                    "aria-label": "Previous"
                },
                U: [g.XI()]
            });
            g.K(this, c);
            c.Ba(this.element);
            c.Pa("click", this.uS, this);
            this.table = new g.PI({
                G: "div",
                L: "ytp-endscreen-content"
            });
            g.K(this, this.table);
            this.table.Ba(this.element);
            c = new g.W({
                G: "button",
                Ha: ["ytp-button", "ytp-endscreen-next"],
                W: {
                    "aria-label": "Next"
                },
                U: [g.YI()]
            });
            g.K(this, c);
            c.Ba(this.element);
            c.Pa("click", this.tS, this);
            a.getVideoData().lc ? this.j = new f5(a, !0) : this.j = new k5(a);
            g.K(this, this.j);
            g.fM(this.player, this.j.element, 4);
            this.hide()
        },
        r5 = function(a) {
            return g.gM(a.player) && a.Tv() && !a.C
        },
        s5 = function(a) {
            var b = a.ze();
            b !== a.K && (a.K = b, a.player.ea("autonavvisibility"))
        },
        t5 = function(a) {
            g.sM.call(this, a);
            var b = this;
            this.endScreen = null;
            this.j = this.u = this.B = !1;
            this.listeners = new g.KA(this);
            g.K(this, this.listeners);
            this.env = a.V();
            fZa(a) ? (this.B = !0, gZa(this), this.j ? this.endScreen = new m5(a) : this.endScreen = new q5(this.player)) : this.env.Qd ? this.endScreen = new o5(this.player) : this.endScreen = new j5(this.player);
            g.K(this, this.endScreen);
            g.fM(this.player, this.endScreen.element, 4);
            hZa(this);
            this.listeners.T(a, "videodatachange", this.onVideoDataChange, this);
            this.listeners.T(a, g.ox("endscreen"), function(c) {
                b.onCueRangeEnter(c)
            });
            this.listeners.T(a, g.px("endscreen"), function(c) {
                b.onCueRangeExit(c)
            })
        },
        gZa = function(a) {
            var b = a.player.getVideoData();
            if (!b || a.j === b.Rh && a.u === b.lc) return !1;
            a.j = b.Rh;
            a.u = b.lc;
            return !0
        },
        fZa = function(a) {
            a = a.V();
            return !a.K && a.Gb && !a.Qd
        },
        hZa = function(a) {
            a.player.kf("endscreen");
            var b = a.player.getVideoData();
            b = new g.mx(Math.max(1E3 * (b.lengthSeconds - 10), 0), 0x8000000000000, {
                id: "preload",
                namespace: "endscreen"
            });
            var c = new g.mx(0x8000000000000, 0x8000000000000, {
                id: "load",
                priority: 8,
                namespace: "endscreen"
            });
            a.player.Nd([b, c])
        };
    g.ZL.prototype.mq = g.da(4, function() {
        return this.app.mq()
    });
    g.vW.prototype.mq = g.da(3, function() {
        return this.getVideoData().nP
    });
    g.w(d5, g.W);
    d5.prototype.select = function() {
        (this.I.pk(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.pw || void 0) || this.I.S("web_player_endscreen_double_log_fix_killswitch")) && this.I.xb(this.element)
    };
    d5.prototype.onClick = function(a) {
        g.SM(a, this.I, this.j, this.suggestion.sessionData || void 0) && this.select()
    };
    d5.prototype.onKeyPress = function(a) {
        switch (a.keyCode) {
            case 13:
            case 32:
                g.dt(a) || (this.select(), g.ct(a))
        }
    };
    g.w(f5, g.W);
    g.h = f5.prototype;
    g.h.gz = function(a) {
        this.suggestion !== a && (this.suggestion = a, c5(this.j, a), this.playButton.Ma("url", this.suggestion.fl()), i5(this))
    };
    g.h.Qh = function() {
        return 0 < this.u
    };
    g.h.Gu = function() {
        this.Qh() || (this.u = Date.now(), e5(this), dZa(this.I, h5(this)), g.M(this.I.getRootNode(), "countdown-running", this.Qh()))
    };
    g.h.Uq = function() {
        this.qn();
        e5(this);
        var a = this.j.Da("ytp-autonav-endscreen-upnext-header");
        a && g.wi(a, "Up next")
    };
    g.h.qn = function() {
        this.Qh() && (this.C.stop(), this.u = 0)
    };
    g.h.select = function(a) {
        this.I.nextVideo(!1, void 0 === a ? !1 : a);
        this.qn()
    };
    g.h.PJ = function(a) {
        g.SM(a, this.I) && (a.currentTarget === this.playButton.element ? this.I.xb(this.playButton.element) : a.currentTarget === this.j.Da("ytp-autonav-endscreen-link-container") && (a = this.j.Da("ytp-autonav-endscreen-link-container"), this.I.fb(a, !0), this.I.xb(a)), this.select())
    };
    g.h.oS = function() {
        this.I.xb(this.cancelButton.element);
        g.aM(this.I, !0);
        this.D && this.I.Qa("innertubeCommand", this.D)
    };
    g.h.onVideoDataChange = function(a, b) {
        a = b.K_;
        this.D = null === a || void 0 === a ? void 0 : a.command
    };
    g.h.OJ = function() {
        var a = this.I.ze();
        this.J && this.vb !== a && g.SI(this, a);
        i5(this);
        this.I.fb(this.element, a);
        this.I.fb(this.cancelButton.element, a);
        this.I.fb(this.j.Da("ytp-autonav-endscreen-link-container"), a);
        this.I.fb(this.playButton.element, a)
    };
    g.h.Ef = function(a) {
        return 400 > a.width || 459 > a.height
    };
    g.w(j5, g.W);
    g.h = j5.prototype;
    g.h.create = function() {
        this.created = !0
    };
    g.h.destroy = function() {
        this.created = !1
    };
    g.h.Tv = function() {
        return !1
    };
    g.h.ze = function() {
        return !1
    };
    g.h.eN = function() {
        return !1
    };
    g.w(k5, g.W);
    g.h = k5.prototype;
    g.h.Kz = function() {
        this.notification && (this.C.stop(), this.wc(this.B), this.B = null, this.notification.close(), this.notification = null)
    };
    g.h.gz = function(a) {
        this.suggestion = a;
        c5(this, a, "hqdefault.jpg")
    };
    g.h.QJ = function() {
        g.SI(this, this.api.ze());
        this.api.fb(this.element, this.api.ze());
        this.api.fb(this.Da("ytp-upnext-autoplay-icon"), this.api.ze());
        this.cancelButton && this.api.fb(this.cancelButton.element, this.api.ze())
    };
    g.h.wX = function() {
        window.focus();
        this.Kz()
    };
    g.h.Gu = function(a) {
        var b = this;
        this.Qh() || (g.tt("a11y-announce", "Up Next " + this.suggestion.title), this.u = (0, g.Q)(), this.j = new g.L(function() {
            l5(b, a)
        }, 25), l5(this, a), dZa(this.api, eZa(this, a)));
        g.Hp(this.element, "ytp-upnext-autoplay-paused")
    };
    g.h.hide = function() {
        g.W.prototype.hide.call(this)
    };
    g.h.Qh = function() {
        return !!this.j
    };
    g.h.Uq = function() {
        this.qn();
        this.u = (0, g.Q)();
        l5(this);
        g.Fp(this.element, "ytp-upnext-autoplay-paused")
    };
    g.h.qn = function() {
        this.Qh() && (this.j.dispose(), this.j = null)
    };
    g.h.select = function(a) {
        a = void 0 === a ? !1 : a;
        if (this.api.V().S("autonav_notifications") && a && window.Notification && "function" === typeof document.hasFocus) {
            var b = Notification.permission;
            "default" === b ? Notification.requestPermission() : "granted" !== b || document.hasFocus() || (this.Kz(), this.notification = new Notification("Up Next", {
                body: this.suggestion.title,
                icon: this.suggestion.Te()
            }), this.B = this.T(this.notification, "click", this.wX), this.C.start())
        }
        this.qn();
        this.api.nextVideo(!1, a)
    };
    g.h.qS = function(a) {
        !g.vi(this.cancelButton.element, g.Zs(a)) && g.SM(a, this.api) && (this.api.ze() && this.api.xb(this.Da("ytp-upnext-autoplay-icon")), this.select())
    };
    g.h.pS = function() {
        this.api.ze() && this.cancelButton && this.api.xb(this.cancelButton.element);
        g.aM(this.api, !0)
    };
    g.h.nX = function(a) {
        this.api.getPresentingPlayerType();
        this.show();
        this.Gu(a)
    };
    g.h.oX = function() {
        this.api.getPresentingPlayerType();
        this.qn();
        this.hide()
    };
    g.h.va = function() {
        this.qn();
        this.Kz();
        g.W.prototype.va.call(this)
    };
    g.w(m5, j5);
    g.h = m5.prototype;
    g.h.create = function() {
        j5.prototype.create.call(this);
        this.C.T(this.player, "appresize", this.Dv);
        this.C.T(this.player, "onVideoAreaChange", this.Dv);
        this.C.T(this.player, "videodatachange", this.onVideoDataChange);
        this.C.T(this.player, "autonavchange", this.RJ);
        this.C.T(this.player, "autonavcancel", this.rS);
        this.onVideoDataChange()
    };
    g.h.show = function() {
        j5.prototype.show.call(this);
        (this.J || this.B && this.B !== this.videoData.clientPlaybackNonce) && g.aM(this.player, !1);
        g.gM(this.player) && this.Tv() && !this.B ? (n5(this), 2 === this.videoData.autonavState ? this.player.V().S("fast_autonav_in_background") && 3 === this.player.getVisibilityState() ? this.j.select(!0) : this.j.Gu() : 3 === this.videoData.autonavState && this.j.Uq()) : (g.aM(this.player, !0), n5(this));
        this.Dv()
    };
    g.h.hide = function() {
        j5.prototype.hide.call(this);
        this.j.Uq();
        n5(this)
    };
    g.h.Dv = function() {
        var a = this.player.Jj(!0, this.player.isFullscreen());
        n5(this);
        i5(this.u);
        g.M(this.element, "ytp-autonav-cancelled-small-mode", this.Ef(a));
        g.M(this.element, "ytp-autonav-cancelled-tiny-mode", this.PA(a));
        g.M(this.element, "ytp-autonav-cancelled-mini-mode", 400 >= a.width || 360 >= a.height);
        this.overlay && g.Qm(this.overlay.element, {
            width: a.width + "px"
        });
        if (!this.D) {
            a = g.q(this.videos.entries());
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = g.q(b.value);
                b = c.next().value;
                c = c.next().value;
                g.M(c.element,
                    "ytp-suggestion-card-with-margin", 1 === b % 2)
            }
        }
    };
    g.h.onVideoDataChange = function() {
        var a = this.player.getVideoData();
        if (this.videoData !== a && a) {
            this.videoData = a;
            if ((a = this.videoData.suggestions) && a.length) {
                this.j.gz(a[0]);
                this.j !== this.u && this.u.gz(a[0]);
                for (var b = 0; b < iZa.length; ++b) {
                    var c = iZa[b];
                    if (a && a[c]) {
                        this.videos[b] = new d5(this.player);
                        var d = this.videos[b];
                        c = a[c];
                        d.suggestion !== c && (d.suggestion = c, c5(d, c));
                        g.K(this, this.videos[b]);
                        this.videos[b].Ba(this.K.element)
                    }
                }
            }
            this.Dv()
        }
    };
    g.h.RJ = function(a) {
        1 === a ? (this.J = !1, this.B = this.videoData.clientPlaybackNonce, this.j.qn(), this.vb && this.Dv()) : (this.J = !0, this.ze() && (2 === a ? this.j.Gu() : 3 === a && this.j.Uq()))
    };
    g.h.rS = function(a) {
        a ? this.RJ(1) : (this.B = null, this.J = !1)
    };
    g.h.Tv = function() {
        return 1 !== this.videoData.autonavState
    };
    g.h.Ef = function(a) {
        return (910 > a.width || 459 > a.height) && !this.PA(a) && !(400 >= a.width || 360 >= a.height)
    };
    g.h.PA = function(a) {
        return 800 > a.width && !(400 >= a.width || 360 >= a.height)
    };
    g.h.ze = function() {
        return this.vb && g.gM(this.player) && this.Tv() && !this.B
    };
    var iZa = [1, 3, 2, 4];
    g.w(o5, j5);
    o5.prototype.Ka = function() {
        var a = this.player.getVideoData();
        this.j.update({
            profilePicture: a.profilePicture,
            author: a.author
        });
        this.subscribeButton.channelId = a.sj;
        var b = this.subscribeButton;
        a.subscribed ? b.u() : b.B()
    };
    g.w(p5, g.W);
    p5.prototype.select = function() {
        (this.api.pk(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.pw || void 0) || this.api.S("web_player_endscreen_double_log_fix_killswitch")) && this.api.xb(this.element)
    };
    p5.prototype.onClick = function(a) {
        g.SM(a, this.api, this.u, this.suggestion.sessionData || void 0) && this.select()
    };
    p5.prototype.onKeyPress = function(a) {
        switch (a.keyCode) {
            case 13:
            case 32:
                g.dt(a) || (this.select(), g.ct(a))
        }
    };
    p5.prototype.onVideoDataChange = function() {
        var a = this.api.getVideoData(),
            b = this.api.V();
        this.u = a.D ? !1 : b.j
    };
    g.w(q5, j5);
    g.h = q5.prototype;
    g.h.create = function() {
        j5.prototype.create.call(this);
        var a = this.player.getVideoData();
        a && (this.videoData = a);
        this.Ol();
        this.u.T(this.player, "appresize", this.Ol);
        this.u.T(this.player, "onVideoAreaChange", this.Ol);
        this.u.T(this.player, "videodatachange", this.onVideoDataChange);
        this.u.T(this.player, "autonavchange", this.rD);
        this.u.T(this.player, "autonavcancel", this.sS);
        a = this.videoData.autonavState;
        a !== this.N && this.rD(a);
        this.u.T(this.element, "transitionend", this.KY)
    };
    g.h.destroy = function() {
        g.Uv(this.u);
        g.vf(this.stills);
        this.stills = [];
        j5.prototype.destroy.call(this);
        g.Hp(this.element, "ytp-show-tiles");
        this.J.stop();
        this.N = this.videoData.autonavState
    };
    g.h.Tv = function() {
        return 1 !== this.videoData.autonavState
    };
    g.h.show = function() {
        j5.prototype.show.call(this);
        g.Hp(this.element, "ytp-show-tiles");
        this.player.V().isMobile ? g.zp(this.J) : this.J.start();
        (this.D || this.C && this.C !== this.videoData.clientPlaybackNonce) && g.aM(this.player, !1);
        r5(this) ? (s5(this), 2 === this.videoData.autonavState ? this.player.V().S("fast_autonav_in_background") && 3 === this.player.getVisibilityState() ? this.j.select(!0) : this.j.Gu() : 3 === this.videoData.autonavState && this.j.Uq()) : (g.aM(this.player, !0), s5(this))
    };
    g.h.hide = function() {
        j5.prototype.hide.call(this);
        this.j.Uq();
        s5(this)
    };
    g.h.KY = function(a) {
        g.Zs(a) === this.element && this.Ol()
    };
    g.h.Ol = function() {
        if (this.videoData && this.videoData.suggestions && this.videoData.suggestions.length) {
            g.Fp(this.element, "ytp-endscreen-paginate");
            var a = this.I.Jj(!0, this.I.isFullscreen()),
                b = g.WL(this.I);
            b && (b = b.bf() ? 48 : 32, a.width -= 2 * b);
            var c = a.width / a.height,
                d = 96 / 54,
                e = b = 2,
                f = Math.max(a.width / 96, 2),
                k = Math.max(a.height / 54, 2),
                l = this.videoData.suggestions.length,
                m = Math.pow(2, 2);
            var n = l * m + (Math.pow(2, 2) - m);
            n += Math.pow(2, 2) - m;
            for (n -= m; 0 < n && (b < f || e < k);) {
                var p = b / 2,
                    r = e / 2,
                    t = b <= f - 2 && n >= r * m,
                    u = e <= k - 2 && n >= p * m;
                if ((p +
                        1) / r * d / c > c / (p / (r + 1) * d) && u) n -= p * m, e += 2;
                else if (t) n -= r * m, b += 2;
                else if (u) n -= p * m, e += 2;
                else break
            }
            d = !1;
            n >= 3 * m && 6 >= l * m - n && (4 <= e || 4 <= b) && (d = !0);
            m = 96 * b;
            n = 54 * e;
            c = m / n < c ? a.height / n : a.width / m;
            c = Math.min(c, 2);
            m = Math.floor(Math.min(a.width, m * c));
            n = Math.floor(Math.min(a.height, n * c));
            a = this.table.element;
            g.$m(a, m, n);
            g.Qm(a, {
                marginLeft: m / -2 + "px",
                marginTop: n / -2 + "px"
            });
            this.j.gz(this.videoData.suggestions[0]);
            this.j instanceof f5 && i5(this.j);
            g.M(this.element, "ytp-endscreen-takeover", r5(this));
            s5(this);
            m += 4;
            n += 4;
            for (f =
                c = 0; f < b; f++)
                for (k = 0; k < e; k++)
                    if (r = c, p = 0, d && f >= b - 2 && k >= e - 2 ? p = 1 : 0 === k % 2 && 0 === f % 2 && (2 > k && 2 > f ? 0 === k && 0 === f && (p = 2) : p = 2), r = g.Ah(r + this.B, l), 0 !== p) {
                        t = this.stills[c];
                        t || (t = new p5(this.player), this.stills[c] = t, a.appendChild(t.element));
                        u = Math.floor(n * k / e);
                        var x = Math.floor(m * f / b),
                            y = Math.floor(n * (k + p) / e) - u - 4,
                            z = Math.floor(m * (f + p) / b) - x - 4;
                        g.Wm(t.element, x, u);
                        g.$m(t.element, z, y);
                        g.Qm(t.element, "transitionDelay", (k + f) / 20 + "s");
                        g.M(t.element, "ytp-videowall-still-mini", 1 === p);
                        g.M(t.element, "ytp-videowall-still-large",
                            2 < p);
                        p = t;
                        r = this.videoData.suggestions[r];
                        p.suggestion !== r && (p.suggestion = r, t = p.api.V(), u = g.Ep(p.element, "ytp-videowall-still-large") ? "hqdefault.jpg" : "mqdefault.jpg", c5(p, r, u), g.$C(t) && (u = r.fl(), x = {}, t.ya && g.XK(x, t.loaderUrl), u = g.Dj(u, g.WK(x, "emb_rel_end")), p.Ma("url", u)), (r = (r = r.sessionData) && r.itct) && p.api.fk(p.element, r));
                        c++
                    }
            g.M(this.element, "ytp-endscreen-paginate", c < l);
            for (b = this.stills.length - 1; b >= c; b--) e = this.stills[b], g.ti(e.element), g.uf(e);
            this.stills.length = c
        }
    };
    g.h.onVideoDataChange = function() {
        var a = this.player.getVideoData();
        this.videoData !== a && (this.B = 0, this.videoData = a, this.Ol())
    };
    g.h.tS = function() {
        this.B += this.stills.length;
        this.Ol()
    };
    g.h.uS = function() {
        this.B -= this.stills.length;
        this.Ol()
    };
    g.h.eN = function() {
        return this.j.Qh()
    };
    g.h.rD = function(a) {
        1 === a ? (this.D = !1, this.C = this.videoData.clientPlaybackNonce, this.j.qn(), this.vb && this.Ol()) : (this.D = !0, this.vb && r5(this) && (2 === a ? this.j.Gu() : 3 === a && this.j.Uq()))
    };
    g.h.sS = function(a) {
        if (a) {
            for (a = 0; a < this.stills.length; a++) this.I.fb(this.stills[a].element, !0);
            this.rD(1)
        } else this.C = null, this.D = !1;
        this.Ol()
    };
    g.h.ze = function() {
        return this.vb && r5(this)
    };
    g.w(t5, g.sM);
    g.h = t5.prototype;
    g.h.wr = function() {
        var a = this.player.getVideoData(),
            b = !!(a && a.suggestions && a.suggestions.length);
        b = !fZa(this.player) || b;
        var c = a.le || g.kD(a.B),
            d = this.player.yw();
        a = a.mutedAutoplay;
        return b && !c && !d && !a
    };
    g.h.ze = function() {
        return this.endScreen.ze()
    };
    g.h.lV = function() {
        return this.ze() ? this.endScreen.eN() : !1
    };
    g.h.va = function() {
        this.player.kf("endscreen");
        g.sM.prototype.va.call(this)
    };
    g.h.load = function() {
        var a = this.player.getVideoData();
        var b = a.GN;
        if (b && b.videoId) {
            var c = this.player.ub().Ld.get("heartbeat");
            a && a.suggestions && a.suggestions.length && b.videoId === a.suggestions[0].videoId && !a.AK ? a = !1 : (this.player.pk(b.videoId, void 0, void 0, !0, !0, b), c && c.YA("HEARTBEAT_ACTION_TRIGGER_AT_STREAM_END", "HEARTBEAT_ACTION_TRANSITION_REASON_HAS_NEW_STREAM_TRANSITION_ENDPOINT"), a = !0)
        } else a = !1;
        a || (g.sM.prototype.load.call(this), this.endScreen.show())
    };
    g.h.unload = function() {
        g.sM.prototype.unload.call(this);
        this.endScreen.hide();
        this.endScreen.destroy()
    };
    g.h.onCueRangeEnter = function(a) {
        this.wr() && (this.endScreen.created || this.endScreen.create(), "load" === a.getId() && this.load())
    };
    g.h.onCueRangeExit = function(a) {
        "load" === a.getId() && this.loaded && this.unload()
    };
    g.h.onVideoDataChange = function() {
        hZa(this);
        this.B && gZa(this) && (this.endScreen && (this.endScreen.hide(), this.endScreen.created && this.endScreen.destroy(), this.endScreen.dispose()), this.j ? this.endScreen = new m5(this.player) : this.endScreen = new q5(this.player), g.K(this, this.endScreen), g.fM(this.player, this.endScreen.element, 4))
    };
    g.rM("endscreen", t5);
})(_yt_player);