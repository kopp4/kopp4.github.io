function Zip() {
    /*
    ■郵便番号から住所情報の自動入力処理(zipaddrx.js Ver7.94)

    The use is free of charge.// ご利用は無料です。
    @demo   https://zipaddr.com/
    @author https://pierre-soft.com/

    [htmlの定義]
      <script src="https://zipaddr.github.io/zipaddrx.js" charset="UTF-8"></script>
    */
    this.xvr = "7.94";
    this.nodb = "2";
    this.advance = "";
    this.jsafter = "";
    this.pt = "1";
    this.pn = "1";
    this.sl = "---選択";
    this.sc = "";
    this.lin = "--------";
    this.dli = "-";
    this.mrk = "〒";
    this.bgc = "#009999";
    this.bgm = "#0099cc";
    this.ovr = "#00bbff";
    this.lnc = "#ffffcc";
    this.clr = "#333333";
    this.fweight = "";
    this.design = "1";
    this.family = "ヒラギノ角ゴ Pro W3,Hiragino Kaku Gothic Pro,メイリオ,Meiryo,ＭＳ Ｐゴシック,sans-serif";
    this.debug = "";
    this.min = "7";
    this.max = "7";
    this.sel = "10";
    this.wok = "";
    this.left = 22;
    this.top = 18;
    this.pfon = "12";
    this.phig = "1.4";
    this.sfon = "16";
    this.shig = "1.6";
    this.emsg = "1";
    this.rtrv = "1";
    this.rtrs = "";
    this.welcart = "";
    this.usces = "";
    this.wp = "";
    this.dyna = "";
    this.eccube = "";
    this.basercms = "";
    this.guideg = "";
    this.reverse = "";
    this.rmin = "2";
    this.rsel = "15";
    this.sphone = "";
    this.opt = "_____";
    this.guide = "@head@page@line&nbsp;@count@close&nbsp;@zipaddr";
    this.contract = "TgeWyKPsMMRT";
    this.zp = "zip";
    this.zp1 = "zip1";
    this.pr = "pref";
    this.ci = "city";
    this.ar = "area";
    this.ad = "addr";
    this.zp2 = "zip2";
    this.zp21 = "zip21";
    this.pr2 = "pref2";
    this.ci2 = "city2";
    this.ar2 = "area2";
    this.ad2 = "addr2";
    this.zp3 = "zip3";
    this.zp31 = "zip31";
    this.pr3 = "pref3";
    this.ci3 = "city3";
    this.ar3 = "area3";
    this.ad3 = "addr3";
    this.zp4 = "zip4";
    this.zp41 = "zip41";
    this.pr4 = "pref4";
    this.ci4 = "city4";
    this.ar4 = "area4";
    this.ad4 = "addr4";
    this.zp5 = "zip5";
    this.zp51 = "zip51";
    this.pr5 = "pref5";
    this.ci5 = "city5";
    this.ar5 = "area5";
    this.ad5 = "addr5";
    this.zp6 = "zip6";
    this.zp61 = "zip61";
    this.pr6 = "pref6";
    this.ci6 = "city6";
    this.ar6 = "area6";
    this.ad6 = "addr6";
    this.zipmax = 6;
    this.focus = "";
    this.sysid = "";
    this.pm = new Array();
    this.zipaddr = "zipaddr";
    this.uver = "";
    this.xzp = "";
    this.xzz = "";
    this.xpr = "";
    this.xci = "";
    this.xar = "";
    this.xad = "";
    this.p = new Array();
    this.q = new Array();
    this.r = new Array();
    this.i = new Array();
    this.e = new Array();
    this.a = new Array();
    this.f = new Array();
    this.preftable = new Array();
    this.adv = new Array();
    this.xul = new Array();
    this.xuls = new Array();
    this.sv = "";
    this.ua;
    this.xuse = 0;
    this.xlisten = "";
    this.ajax = "";
    this.bro = "";
    this.elid = "call" + this.zipaddr;
    this.apad = "";
    this.after = "";
    this.woo = "";
    this.mai = "";
    this.msg1 = "**郵番の設置は最大20箇所迄です。";
    this.msg2 = "**Listen 70over, Please TEL " + this.zipaddr;
    this.m = "";
    this.n = "[住所自動入力]_start！";
    this.lang = "";
    this.Running = false;
    this.holder = "";
    this.zipaddr0 = "https://zipaddr.com/";
    this.zipaddr2 = "http://zipaddr2.com/";
    this.help = this.zipaddr0;
    Chngt = [];
    Chngt['[住所自動入力]_start！'] = "Search start!";
    Chngt['Search start!'] = "Search start!";
    Chngt['〒'] = "";
    Chngt['閉じる'] = "Close";
    Chngt['先頭'] = "Top";
    Chngt['最終'] = "Last";
    Chngt['件ヒット'] = "_Hit!"
}
let D = new Zip;

function Dmy() {}
let ZP = new Dmy;

function zipaddr_compa() {
    if (typeof ZP.sysid !== "undefined") D.sysid = ZP.sysid;
    if (typeof ZP.min !== "undefined") D.min = ZP.min
}
Zip.zip2addr = function(a, b, c, d) {};
Zip.in3 = function() {
    Zip.chk(3)
};
Zip.in6 = function() {
    Zip.chk(6)
};
Zip.s1 = function(c, f, u) {
    if (c == 1) {
        Bas.av(f, u, Zip.in1)
    } else if (c == 2) {
        Bas.av(f, u, Zip.in2)
    } else if (c == 3) {
        Bas.av(f, u, Zip.in3)
    } else if (c == 4) {
        Bas.av(f, u, Zip.in4)
    } else if (c == 5) {
        Bas.av(f, u, Zip.in5)
    } else if (c == 6) {
        Bas.av(f, u, Zip.in6)
    } else if (c == 7) {
        Bas.av(f, u, Zip.in7)
    } else if (c == 8) {
        Bas.av(f, u, Zip.in8)
    } else if (c == 9) {
        Bas.av(f, u, Zip.in9)
    } else if (c == 10) {
        Bas.av(f, u, Zip.in10)
    } else if (c == 11) {
        Bas.av(f, u, Zip.in11)
    } else if (c == 12) {
        Bas.av(f, u, Zip.in12)
    } else if (c == 13) {
        Bas.av(f, u, Zip.in13)
    } else if (c == 14) {
        Bas.av(f, u, Zip.in14)
    } else if (c == 15) {
        Bas.av(f, u, Zip.in15)
    } else if (c == 16) {
        Bas.av(f, u, Zip.in16)
    } else if (c == 17) {
        Bas.av(f, u, Zip.in17)
    } else if (c == 18) {
        Bas.av(f, u, Zip.in18)
    } else if (c == 19) {
        Bas.av(f, u, Zip.in19)
    } else if (c == 20) {
        Bas.av(f, u, Zip.in20)
    }
};
Zip.ir16 = function() {
    Zip.r0(16)
};
Zip.wu = function() {
    if (!document.getElementById("zipcode")) {
        D.zipmax = 4;
        let f = new Array();
        f[1] = "member";
        f[2] = "customer";
        f[3] = "delivery";
        for (let g = 1; g < D.zipmax; g++) {
            const w = Bas.gi(f[g] + "[zipcode]");
            const b = Bas.gi(f[g] + "[pref]");
            const v = Bas.gi(f[g] + "[address1]");
            const h = Bas.gi(f[g] + "[address2]");
            Zip.e5(g, w, "", b, "", v, h, h)
        }
        Bas.gi("zip_code");
        Bas.gi("address1");
        Zip.e5(D.zipmax, "zip_code", "", "", "", "address1", "", "")
    }
};
Zip.fc16 = function() {
    Zip.c0(16, D.p[16], D.q[16])
};
Zip.in12 = function() {
    Zip.chk(12)
};
Zip.th = function() {
    if (D.wpmem_reg == "1") {
        if (document.getElementById("wpmem_reg")) {
            const t = "billing_";
            const g = t + "postcode";
            const z = t + "state";
            const c = t + "city";
            const b = t + "address_1";
            D.pm[1] = {
                "zip": g,
                "zip1": "",
                "pref": z,
                "city": c,
                "area": "",
                "addr": b,
                "focus": ""
            };
            D.pm[2] = {
                "zip": "zip",
                "zip1": "",
                "pref": "state",
                "city": "city",
                "area": "",
                "addr": "addr1",
                "focus": ""
            };
            D.zipmax = D.pm.length
        }
    }
};
Zip.in1 = function() {
    Zip.chk(1)
};
Zip.ir3 = function() {
    Zip.r0(3)
};
Zip.ir14 = function() {
    Zip.r0(14)
};
Zip.in9 = function() {
    Zip.chk(9)
};
Zip.in13 = function() {
    Zip.chk(13)
};
Zip.vs = function() {
    const n = D.sysid.split("_");
    for (let b = 0; b < n.length; b++) {
        if (n[b] == "WOOCOMMERCE") {
            D.woo = "1";
            D.after = "1";
            for (let t = 1; t <= 2; t++) {
                const z = (t == 1) ? "billing_" : "shipping_";
                Zip.e5(t, z + "postcode", "", z + "state", z + "city", "", "", z + "address_1")
            }
        } else if (n[b] == "TRUSTFORM") {
            const d = "zip_zip1_pref_city_area_addr";
            const f = d.split("_");
            for (let s = 0; s < f.length; s++) {
                const w = f[s];
                Bas.cs(w)
            }
        } else if (n[b] == "CSCART") {
            D.help = D.zipaddr0 + "cscart/"
        }
    }
};
Zip.in19 = function() {
    Zip.chk(19)
};
Zip.fc12 = function() {
    Zip.c0(12, D.p[12], D.q[12])
};
Zip.ir9 = function() {
    Zip.r0(9)
};
Zip.m = function() {
    D.help = D.zipaddr0 + "basercms/"
};
Zip.w9 = function() {
    D.help = D.zipaddr2 + "wordpress/"
};
Zip.fc10 = function() {
    Zip.c0(10, D.p[10], D.q[10])
};
Zip.in16 = function() {
    Zip.chk(16)
};
Zip.u6 = function() {
    let n = "";
    if ((D.ua.indexOf('iphone') > 0 && D.ua.indexOf('ipad') == -1) || D.ua.indexOf('android') > 0) n = "1";
    if (typeof fnCallAddress === "function" || window.eccube != undefined) {
        D.eccube = "1";
        if (D.sphone == "" && n == "1") D.sphone = "2"
    } else if (typeof uscesL10n != "undefined" && document.getElementById("zipcode")) {
        D.welcart = "1";
        if (D.sphone == "" && n == "1") D.sphone = "2"
    } else if (D.sphone != "") {} else if (n == "1") D.sphone = "2"
};
Zip.in5 = function() {
    Zip.chk(5)
};
Zip.fc9 = function() {
    Zip.c0(9, D.p[9], D.q[9])
};
Zip.fc15 = function() {
    Zip.c0(15, D.p[15], D.q[15])
};
Zip.fc13 = function() {
    Zip.c0(13, D.p[13], D.q[13])
};
Zip.ir19 = function() {
    Zip.r0(19)
};
Zip.in4 = function() {
    Zip.chk(4)
};
Zip.w = function() {
    const u = "address1";
    const h = "address2";
    const n = "pref";
    const f = "member_pref";
    const z = "customer_pref";
    const y = "delivery_pref";
    if (document.getElementById(n)) Zip.e5(1, "zipcode", "", n, "", u, h, h);
    else if (document.getElementById(f)) Zip.e5(1, "zipcode", "", f, "", u, h, h);
    else if (document.getElementById(z)) Zip.e5(1, "zipcode", "", z, "", u, h, h);
    else if (document.getElementById(y)) Zip.e5(1, "zipcode", "", y, "", u, h, h);
    D.zipmax = 1
};
Zip.aa = function(s) {
    if (D.ajax == "") {
        D.ajax = "1";
        Zip.x()
    }
    if (D.ajax == "1") {
        const r = s.id;
        for (let h = 1; h <= D.zipmax; h++) {
            if (D.p[h] == r && document.getElementById(r)) {
                Zip.chk(h);
                break
            }
        }
    }
};
Zip.fc19 = function() {
    Zip.c0(19, D.p[19], D.q[19])
};
Zip.lb = function() {
    let p = "";
    const q = document.getElementsByTagName("label");
    for (let u = 0; u < q.length; u++) {
        let a = q[u].innerHTML;
        a = a.replace(/　/g, '');
        a = a.replace(/ /g, '');
        if (a.match(/都道府県/)) {
            p = q[u].id.replace('label-', '');
            break
        }
    }
    return p
};
Zip.sx = function(n, u, h) {
    const w = "keyup";
    let c = "";
    let e = "";
    let s = "";
    let t = "";
    if (u != "" && document.getElementById(u)) {
        c = document.getElementById(u);
        if (c.getAttribute("type") == null) c.setAttribute("type", "text");
        e = c.getAttribute("type").toLowerCase();
        try {
            s = c.placeholder;
            t = true
        } catch (e) {
            s = "1";
            t = false
        }
    }
    if (u != "" && document.getElementById(u) && e != "hidden") {
        let d = (D.dli == "") ? 7 : 8;
        if (h != "" && document.getElementById(h)) {
            const m = document.getElementById(h);
            Zip.upf(c, m);
            Bas.st(c);
            if (t) Bas.sp(c);
            Zip.s0(n, c, w);
            c = m;
            d = 4
        } else {
            Zip.upf(c, "");
            if (e == "number") {
                d = 7;
                D.dli = ""
            }
        }
        Bas.st(c);
        if (t) Bas.sp(c);
        Zip.s1(n, c, w);
        if (c.maxLength <= 0 || c.maxLength >= 100) c.maxLength = d;
        D.xuse = 1;
        c = document.getElementById(u);
        if (s == "") {
            if (D.holder == "") c.placeholder = "住所自動入力";
            else if (D.holder == "&nbsp;") c.placeholder = "";
            else c.placeholder = D.holder
        }
    }
};
Zip.ir2 = function() {
    Zip.r0(2)
};
Zip.ir13 = function() {
    Zip.r0(13)
};
Zip.ir12 = function() {
    Zip.r0(12)
};
Zip.fc8 = function() {
    Zip.c0(8, D.p[8], D.q[8])
};
Zip.in17 = function() {
    Zip.chk(17)
};
Zip.in2 = function() {
    Zip.chk(2)
};
Zip.in7 = function() {
    Zip.chk(7)
};
Zip.u3 = function() {
    Zip.e5(1, D.zp, D.zp1, D.pr, D.ci, D.ar, D.ad, D.focus);
    Zip.e5(2, D.zp2, D.zp21, D.pr2, D.ci2, D.ar2, D.ad2, D.focus);
    Zip.e5(3, D.zp3, D.zp31, D.pr3, D.ci3, D.ar3, D.ad3, D.focus);
    Zip.e5(4, D.zp4, D.zp41, D.pr4, D.ci4, D.ar4, D.ad4, D.focus);
    Zip.e5(5, D.zp5, D.zp51, D.pr5, D.ci5, D.ar5, D.ad5, D.focus);
    Zip.e5(6, D.zp6, D.zp61, D.pr6, D.ci6, D.ar6, D.ad6, D.focus);
    for (let z = 7; z <= D.zipmax; z++) {
        Zip.e5(z, "zip" + z, "zip" + z + "1", "pref" + z, "city" + z, "area" + z, "addr" + z, D.focus)
    }
};
Zip.rr = function(h, v) {
    if (document.getElementById(v)) {
        const q = document.getElementById(v);
        const x = 'keyup';
        const y = 'change';
        if (h == 1) {
            Bas.av(q, x, Zip.ir1);
            Bas.av(q, y, Zip.ir1)
        } else if (h == 2) {
            Bas.av(q, x, Zip.ir2);
            Bas.av(q, y, Zip.ir2)
        } else if (h == 3) {
            Bas.av(q, x, Zip.ir3);
            Bas.av(q, y, Zip.ir3)
        } else if (h == 4) {
            Bas.av(q, x, Zip.ir4);
            Bas.av(q, y, Zip.ir4)
        } else if (h == 5) {
            Bas.av(q, x, Zip.ir5);
            Bas.av(q, y, Zip.ir5)
        } else if (h == 6) {
            Bas.av(q, x, Zip.ir6);
            Bas.av(q, y, Zip.ir6)
        } else if (h == 7) {
            Bas.av(q, x, Zip.ir7);
            Bas.av(q, y, Zip.ir7)
        } else if (h == 8) {
            Bas.av(q, x, Zip.ir8);
            Bas.av(q, y, Zip.ir8)
        } else if (h == 9) {
            Bas.av(q, x, Zip.ir9);
            Bas.av(q, y, Zip.ir9)
        } else if (h == 10) {
            Bas.av(q, x, Zip.ir10);
            Bas.av(q, y, Zip.ir10)
        } else if (h == 11) {
            Bas.av(q, x, Zip.ir11);
            Bas.av(q, y, Zip.ir11)
        } else if (h == 12) {
            Bas.av(q, x, Zip.ir12);
            Bas.av(q, y, Zip.ir12)
        } else if (h == 13) {
            Bas.av(q, x, Zip.ir13);
            Bas.av(q, y, Zip.ir13)
        } else if (h == 14) {
            Bas.av(q, x, Zip.ir14);
            Bas.av(q, y, Zip.ir14)
        } else if (h == 15) {
            Bas.av(q, x, Zip.ir15);
            Bas.av(q, y, Zip.ir15)
        } else if (h == 16) {
            Bas.av(q, x, Zip.ir16);
            Bas.av(q, y, Zip.ir16)
        } else if (h == 17) {
            Bas.av(q, x, Zip.ir17);
            Bas.av(q, y, Zip.ir17)
        } else if (h == 18) {
            Bas.av(q, x, Zip.ir18);
            Bas.av(q, y, Zip.ir18)
        } else if (h == 19) {
            Bas.av(q, x, Zip.ir19);
            Bas.av(q, y, Zip.ir19)
        } else if (h == 20) {
            Bas.av(q, x, Zip.ir20);
            Bas.av(q, y, Zip.ir20)
        }
    }
};
Zip.fc20 = function() {
    Zip.c0(20, D.p[20], D.q[20])
};
Zip.fc1 = function() {
    Zip.c0(1, D.p[1], D.q[1])
};
Zip.ir8 = function() {
    Zip.r0(8)
};
Zip.y2 = function() {
    if (!D.Running) {
        D.Running = true;
        Zip.x()
    }
};
Zip.yu = function(u) {
    let s;
    let x;
    if (D.xuls[u] == D.xul[u]) {
        s = 'https:';
        x = D.xuls[u]
    } else {
        s = location.protocol;
        x = s == "https:" ? D.xuls[u] : D.xul[u]
    }
    x = s + '/' + '/' + Bas.pr(unescape(x));
    return x
};
Zip.fc4 = function() {
    Zip.c0(4, D.p[4], D.q[4])
};
Zip.in11 = function() {
    Zip.chk(11)
};
Zip.u0 = function() {
    D.xul[0] = "%u3042z%u3046i%u3044pa%u3042d%u3046dr.co%u3042m";
    D.xul[1] = "z%u3044i%u3046pa%u3044dd%u3042r%u30467.c%u3042om";
    D.xul[2] = "%u3046pie%u3042rr%u3046e-%u3044s%u3046o%u3042f%u3044t.%u3042co%u3044m";
    D.xuls[0] = D.xul[0];
    D.xuls[1] = D.xul[1];
    D.xuls[2] = D.xul[2];
    if (D.sv == "") {
        const b = Math.floor(Math.random() * 10);
        if (b >= 4) D.sv = "2";
        else if (b >= 3) D.sv = "1";
        else D.sv = "0"
    }
};
Zip.fc6 = function() {
    Zip.c0(6, D.p[6], D.q[6])
};
Zip.fc5 = function() {
    Zip.c0(5, D.p[5], D.q[5])
};
Zip.x3 = function(c) {
    let u = "";
    for (let n = 0; n < c.length; n++) {
        u = Zip.x4(c[n]);
        if (u != "") break
    }
    return u
};
Zip.in8 = function() {
    Zip.chk(8)
};
Zip.fc2 = function() {
    Zip.c0(2, D.p[2], D.q[2])
};
Zip.ir11 = function() {
    Zip.r0(11)
};
Zip.ir4 = function() {
    Zip.r0(4)
};
Zip.fc3 = function() {
    Zip.c0(3, D.p[3], D.q[3])
};
Zip.x4 = function(u) {
    if (u == "" || document.getElementById(u)) return u;
    else {
        const x = document.getElementsByName(u);
        if (x.length == 1 && (x[0].id == "undefined" || x[0].id == "")) return u
    }
    return ""
};
Zip.ir20 = function() {
    Zip.r0(20)
};
Zip.ir6 = function() {
    Zip.r0(6)
};
Zip.s4 = function() {
    D.min = "7";
    D.left = 30;
    D.top = 25;
    D.sl = "都道府県を選択して下さい。"
};
Zip.fc17 = function() {
    Zip.c0(17, D.p[17], D.q[17])
};
Zip.in14 = function() {
    Zip.chk(14)
};
Zip.x = function() {
    if (typeof zipaddr_ownb === "function") zipaddr_ownb();
    Bas.br();
    Zip.u0();
    Zip.u6();
    if ((D.wp == "2" || D.jsafter == "1" || D.dyna == "1") && D.Running == false) return;
    D.welcart = "";
    let v = "";
    D.sysid = D.sysid.toUpperCase();
    if (D.sysid != "") v = Zip.ups();
    if (v == "1") return;
    D.Running = true;
    Zip.th();
    if (D.welcart == "1") Zip.wr();
    if (D.debug == "1") Zip.d0();
    if (D.eccube == "1" && typeof Zip.q === "function") Zip.q();
    else if (D.basercms == "1" && typeof Zip.m === "function") Zip.m();
    else {
        if (D.welcart == "1" && typeof Zip.w === "function") Zip.w();
        if (D.usces == "1" && typeof Zip.wu === "function") Zip.wu()
    }
    if (D.advance == "1" && typeof Zip.x0 === "function") Zip.x0();
    if ((D.wp == "1" || D.wp == "2") && typeof Zip.w9 === "function") Zip.w9();
    if (D.sphone != "" && typeof Zip.s4 === "function") Zip.s4();
    if (typeof zipaddr_eccube === "function") zipaddr_eccube();
    if (typeof zipaddr_own === "function") zipaddr_own();
    if (D.wp == "2") Zip.ja();
    if (typeof D.pm[1] != "undefined" && D.pm[1] != "") {
        for (let g = 1; g < D.pm.length; g++) {
            const z = D.pm[g];
            const r = (typeof z.zip != "undefined") ? Bas.gi(z.zip) : "";
            const d = (typeof z.zip1 != "undefined") ? Bas.gi(z.zip1) : "";
            const u = (typeof z.pref != "undefined") ? Bas.gi(z.pref) : "";
            const y = (typeof z.city != "undefined") ? Bas.gi(z.city) : "";
            const m = (typeof z.area != "undefined") ? Bas.gi(z.area) : "";
            const s = (typeof z.addr != "undefined") ? Bas.gi(z.addr) : "";
            const t = (typeof z.focus != "undefined") ? Bas.gi(z.focus) : "";
            Zip.e5(g, r, d, u, y, m, s, t)
        }
        D.zipmax = D.pm.length - 1
    } else if (D.eccube == "1" || D.welcart == "1" || D.usces == "1") {} else Zip.u3();
    Zip.c9();
    if (typeof zipaddr_ownc === "function") zipaddr_ownc();
    if (D.sysid != "") Zip.vs();
    for (let e = 1; e <= D.zipmax; e++) {
        if (typeof D.e[e] == "undefined") D.e[e] = "";
        Bas.gi(D.p[e]);
        Bas.gi(D.q[e]);
        Bas.gi(D.r[e]);
        Bas.gi(D.i[e]);
        Bas.gi(D.e[e]);
        Bas.gi(D.a[e]);
        if (e > 20) alert(D.msg1);
        else if (D.p[e] == "") {} else {
            Zip.sx(e, D.p[e], D.q[e]);
            if (D.reverse != "") Zip.u(e, D.a[e])
        }
    }
    if (D.xuse == 1 || D.sysid == "CSCART") Zip.y();
    if (typeof zipaddr_owna === "function") zipaddr_owna()
};
Zip.fc18 = function() {
    Zip.c0(18, D.p[18], D.q[18])
};
Zip.wr = function() {
    const q = "mw-wp-form-js";
    const f = "trust-form";
    const h = "zip";
    if (document.getElementById(q)) D.welcart = "";
    else if (document.getElementById(f)) D.welcart = "";
    else if (document.getElementById(h)) {
        const k = document.getElementById(h);
        const p = k.className;
        if (p.indexOf('wpcf7') != -1) D.welcart = ""
    }
};
Zip.ups = function() {
    let s = "";
    const r = D.sysid.split("_");
    for (let x = 0; x < r.length; x++) {
        if (r[x] == "WELCART") {
            D.welcart = "1";
            break
        } else if (r[x] == "WP-MEMBERS") {
            if (typeof D.wpmem_reg == "undefined") {
                D.wpmem_reg = "";
                D.Running = false;
                s = "1"
            } else {
                D.wpmem_reg = "1"
            }
            break
        }
    }
    return s
};
Zip.ja = function() {
    let y = new Array();
    y[0] = "zip";
    y[1] = Zip.lb();
    y[2] = "city";
    y[3] = "address";
    for (let s = 0; s < y.length; s++) {
        const d = document.getElementsByName(y[s]);
        if (d.length == 1) y[s] = d[0].id
    }
    D.pm[1] = {
        "zip": y[0],
        "zip1": "",
        "pref": y[1],
        "city": y[2],
        "area": "",
        "addr": y[3],
        "focus": y[3]
    };
    D.zipmax = D.pm.length
};
Zip.c9 = function() {
    const d = "zipaddr_param";
    if (document.getElementById(d)) {
        const y = document.getElementById(d);
        const t = y.value.split(",");
        for (let z = 0; z < t.length; z++) {
            const e = t[z].replace(/(^\s+)|(\s+$)/g, "");
            const g = e.split("=");
            if (g.length == 2) {
                const a = g[0];
                const r = g[1];
                if (a == "zip") D.p[1] = r;
                else if (a == "zip1") D.q[1] = r;
                else if (a == "pref") D.r[1] = r;
                else if (a == "city") D.i[1] = r;
                else if (a == "addr") D.a[1] = r;
                else if (a == "zip2") D.p[2] = r;
                else if (a == "zip21") D.q[2] = r;
                else if (a == "pref2") D.r[2] = r;
                else if (a == "city2") D.i[2] = r;
                else if (a == "addr2") D.a[2] = r;
                else if (a == "dli") D.dli = r;
                else if (a == "bgc") D.bgc = r;
                else if (a == "bgm") D.bgm = r;
                else if (a == "ovr") D.ovr = r;
                else if (a == "lnc") D.lnc = r;
                else if (a == "clr") D.clr = r;
                else if (a == "min") D.min = r;
                else if (a == "sel") D.sel = r;
                else if (a == "left") D.left = r;
                else if (a == "top") D.top = r;
                else if (a == "pfon") D.pfon = r;
                else if (a == "phig") D.phig = r;
                else if (a == "sfon") D.sfon = r;
                else if (a == "shig") D.shig = r;
                else if (a == "rtrv") D.rtrv = r;
                else if (a == "rtrs") D.rtrs = r;
                else if (a == "opt") D.opt = r;
                else if (a == "lang") D.lang = r;
                else if (a == "welcart") D.welcart = r;
                else if (a == "eccube") D.eccube = r;
                else if (a == "zipmax") D.zipmax = r;
                else if (a == "focus") D.focus = r;
                else if (a == "sysid") D.sysid = r;
                else if (a == "after") D.after = r;
                else if (a == "debug") D.debug = r
            }
        }
    }
};
Zip.in15 = function() {
    Zip.chk(15)
};
Zip.c0 = function(w, m, s) {
    const u = document.getElementById(m);
    const n = document.getElementById(s);
    const y = Bas.cg(u.value).length;
    const x = Bas.cg(n.value).length;
    if (y == 1 && x == 0) Zip.chk(w);
    else if (y == 3 && x == 4) Zip.chk(w);
    else {
        if (y == 3 && x == 0) {
            if (D.sphone != "") u.blur();
            Bas.fc(n)
        }
        if (D.rtrs == "1" || (D.nodb != "" && y == 3)) Zip.chk(w)
    }
};
Zip.d0 = function() {
    let h = "Start-" + D.zipaddr + "_Ver" + D.xvr + "\n";
    h += "EC-CUBE: " + D.eccube + "\n";
    h += "Welcart: " + D.welcart + "\n";
    h += "SmartPhone:" + D.sphone + "\n";
    h += "Reverse:" + D.reverse + "\n";
    h += "zipmax:" + D.zipmax + "\n";
    h += "sv:" + D.sv + "\n";
    alert(h)
};
Zip.in20 = function() {
    Zip.chk(20)
};
Zip.ir10 = function() {
    Zip.r0(10)
};
Zip.ir1 = function() {
    Zip.r0(1)
};
Zip.ir17 = function() {
    Zip.r0(17)
};
Zip.in10 = function() {
    Zip.chk(10)
};
Zip.in18 = function() {
    Zip.chk(18)
};
Zip.ir15 = function() {
    Zip.r0(15)
};
Zip.q = function() {
    let d = new Array();
    d[1] = "";
    d[2] = "deliv_";
    d[3] = "order_";
    d[4] = "shipping_";
    d[5] = "law_";
    d[6] = "dmy_";
    for (let c = 1; c <= 6; c++) {
        const p = d[c] + "zip01";
        const n = d[c] + "zip02";
        const t = d[c] + "pref";
        const q = d[c] + "addr01";
        const m = d[c] + "addr02";
        const e = d[c] + "addr02";
        Zip.e5(c, p, n, t, "", q, m, e)
    }
    for (let v = 0; v <= 13; v++) {
        const h = v + 7;
        const r = d[4] + "zip01[" + v + "]";
        const a = d[4] + "zip02[" + v + "]";
        const x = d[4] + "pref[" + v + "]";
        const b = d[4] + "city[" + v + "]";
        const w = d[4] + "addr01[" + v + "]";
        const s = d[4] + "addr02[" + v + "]";
        Zip.e5(h, r, a, x, "", b, w, s)
    }
    D.top = 21;
    D.sl = "都道府県を選択";
    D.zipmax = 20;
    D.help = D.zipaddr0 + "eccube/plugin.html"
};
Zip.x0 = function() {
    D.adv[0] = ["zip", "zip1", "ZIP1", "zip01", "ZIP01", "zipcode1", "zip_code1", "zip_1", "post1", "postcode1", "yubin1", "yubin_no1", "txtPostCD1", "zip", "zipcode", "zipCode", "postal", "postcode", "yubin", "yubin_no1"];
    D.adv[1] = ["zip1", "zip2", "ZIP2", "zip02", "ZIP02", "zipcode2", "zip_code2", "zip_2", "post2", "postcod2", "yubin2", "yubin_no2", "txtPostCD2", "", "", "", "", "", "", ""];
    D.adv[2] = ["pref", "prefs", "prefecture", "prefectures", "prefecture_id", "PREFECTURAL", "selKen", "sel_ken", "ken", "stCD"];
    D.adv[3] = ["city", "cities", "txtShinchou"];
    D.adv[4] = ["area", "street"];
    D.adv[5] = ["addr", "addr1", "addr01", "address", "address1", "address01", "ADDRESS", "adrs1", "add", "txtBanchi"];
    D.pr = Zip.x3(D.adv[2]);
    D.ci = Zip.x3(D.adv[3]);
    D.ar = Zip.x3(D.adv[4]);
    D.ad = Zip.x3(D.adv[5]);
    const y = Zip.xx(D.adv[0], D.adv[1]);
    const m = y.split("|");
    D.zp = m[0];
    D.zp1 = m[1];
    D.zp2 = D.zp3 = D.zp4 = D.zp5 = D.zp6 = ""
};
Zip.ir5 = function() {
    Zip.r0(5)
};
Zip.fc7 = function() {
    Zip.c0(7, D.p[7], D.q[7])
};
Zip.fc11 = function() {
    Zip.c0(11, D.p[11], D.q[11])
};
Zip.y = function() {
    if (D.reverse != "" || D.sv == "") D.sv = "0";
    const q = location.host + "|" + location.hostname;
    let c = Zip.yu(D.sv) + "/js/ziparcx_6.php?v=251&u=" + q + "&n=" + D.nodb;
    if (D.reverse != "") c += "&r=85";
    if (D.apad != "") c += "&m=" + D.apad;
    if (D.sv == "1") Bas.ca(c)
};
Zip.s0 = function(m, u, q) {
    if (m == 1) {
        Bas.av(u, q, Zip.fc1)
    } else if (m == 2) {
        Bas.av(u, q, Zip.fc2)
    } else if (m == 3) {
        Bas.av(u, q, Zip.fc3)
    } else if (m == 4) {
        Bas.av(u, q, Zip.fc4)
    } else if (m == 5) {
        Bas.av(u, q, Zip.fc5)
    } else if (m == 6) {
        Bas.av(u, q, Zip.fc6)
    } else if (m == 7) {
        Bas.av(u, q, Zip.fc7)
    } else if (m == 8) {
        Bas.av(u, q, Zip.fc8)
    } else if (m == 9) {
        Bas.av(u, q, Zip.fc9)
    } else if (m == 10) {
        Bas.av(u, q, Zip.fc10)
    } else if (m == 11) {
        Bas.av(u, q, Zip.fc11)
    } else if (m == 12) {
        Bas.av(u, q, Zip.fc12)
    } else if (m == 13) {
        Bas.av(u, q, Zip.fc13)
    } else if (m == 14) {
        Bas.av(u, q, Zip.fc14)
    } else if (m == 15) {
        Bas.av(u, q, Zip.fc15)
    } else if (m == 16) {
        Bas.av(u, q, Zip.fc16)
    } else if (m == 17) {
        Bas.av(u, q, Zip.fc17)
    } else if (m == 18) {
        Bas.av(u, q, Zip.fc18)
    } else if (m == 19) {
        Bas.av(u, q, Zip.fc19)
    } else if (m == 20) {
        Bas.av(u, q, Zip.fc20)
    }
};
Zip.e5 = function(r, d, x, y, m, s, b, h) {
    if (D.debug == "T") alert(r + ":" + d + ":" + x + ":" + y + ":" + m + ":" + s + ":" + b + ":" + h);
    D.p[r] = d;
    D.q[r] = x;
    D.r[r] = y;
    D.i[r] = m;
    D.e[r] = s;
    D.a[r] = b;
    D.f[r] = h
};
Zip.ir7 = function() {
    Zip.r0(7)
};
Zip.ir18 = function() {
    Zip.r0(18)
};
Zip.xx = function(w, v) {
    let h = "";
    let f = "";
    for (let b = 0; b < w.length; b++) {
        f = "";
        h = Zip.x4(w[b]);
        if (h != "") {
            if (v[b] == "") break;
            else {
                f = Zip.x4(v[b]);
                if (f != "") break
            }
        }
    }
    return h + "|" + f
};
Zip.upf = function(w, q) {
    const p = w.value;
    let k = p;
    if (q != "") k += q.value;
    k = k.replace('-', '');
    if (k == "" || k.length == 7) {} else {
        if (q == "") Bas.fc(w);
        else if (p.length < 3) Bas.fc(w);
        else Bas.fc(q)
    }
};
Zip.fc14 = function() {
    Zip.c0(14, D.p[14], D.q[14])
};
if (window.addEventListener) {
    window.addEventListener('load', Zip.x, true);
    window.addEventListener('keyup', Zip.y2, true)
} else if (window.attachEvent) {
    window.attachEvent('onload', Zip.x, true)
}
try {
    $(document).on('pageinit', function(e) {
        D.sphone = "1";
        Zip.x()
    })
} catch (e) {}
Bas.gi = function(t) {
    let u = t;
    if (t == "" || document.getElementById(t)) {} else {
        const s = document.getElementsByName(t);
        if (s.length == 1 && (s[0].id == "undefined" || s[0].id == "")) {
            u = u.replace(/\[/g, "");
            u = u.replace(/\]/g, "");
            s[0].id = u
        } else if (s.length == 1) u = s[0].id
    }
    return u
};
Bas.fc = function(n) {
    const b = n.value.length;
    n.focus();
    if (n.createTextRange) {
        const v = n.createTextRange();
        v.move('character', b);
        v.select()
    } else if (n.setSelectionRange) {
        n.setSelectionRange(b, b)
    }
};
Bas.cg = function(s) {
    let w = Bas.zh(s);
    w = w.replace(/-/g, '');
    w = w.replace(/\s/g, '');
    return w
};
Bas.sc = function(e) {
    if (e.length < 14) return false;
    const x = e.slice(2, -2);
    let y = x.length;
    if (y < 10) return false;
    const u = x.substr(1, 1);
    const p = x.substr(-3, 1);
    const d = x.substr(-1, 1);
    let m = x.substr(2, y - 6);
    m = Bas.pr(unescape(m));
    y = (m.length + 65) % 100;
    y = ("00" + y.toString(10)).slice(-2);
    if (u != y.substr(0, 1)) return false;
    if (p != y.substr(1, 1)) return false;
    if (d != m.split(".").length) return false;
    if (m != location.hostname) return false;
    return true
};
Bas.er = function(r, m) {
    let p;
    if (document.getElementById(r)) {
        p = document.getElementById(r)
    } else {
        p = document.createElement('div');
        p.id = r;
        let g = m;
        if (g == "") g = document.getElementsByTagName("body").item(0);
        g.appendChild(p)
    }
    return p
};
Bas.st = function(x) {
    x.style.imeMode = "disabled"
};

function Bas() {
    this.ver = 1.12
}
Bas.ca = function(k) {
    if (D.debug == "T") alert(k);
    Bas.es(D.elid);
    const z = document.createElement("script");
    z.id = D.elid;
    z.setAttribute("type", "text/javascript");
    z.setAttribute("src", k);
    z.setAttribute("charset", "UTF-8");
    document.body.appendChild(z)
};
Bas.es = function(p) {
    if (document.getElementById(p)) {
        const g = document.getElementById(p);
        const f = document.getElementsByTagName("body").item(0);
        f.removeChild(g)
    }
};
Bas.pr = function(h) {
    let k = h.replace(/う/g, '');
    k = k.replace(/あ/g, '');
    k = k.replace(/い/g, '');
    k = k.replace(/え/g, '');
    return k
};
Bas.br = function() {
    D.ua = window.navigator.userAgent.toLowerCase();
    const d = window.navigator.appVersion.toLowerCase();
    let a;
    if (D.ua.indexOf("msie") > -1) {
        if (d.indexOf("msie 6.") > -1) {
            a = "IE6"
        } else if (d.indexOf("msie 7.") > -1) {
            a = "IE7"
        } else if (d.indexOf("msie 8.") > -1) {
            a = "IE8"
        } else if (d.indexOf("msie 9.") > -1) {
            a = "IE9"
        } else if (d.indexOf("msie 10.") > -1) {
            a = "IE10"
        } else {
            a = "IE"
        }
    } else if (D.ua.indexOf("trident/7") > -1) {
        a = "IE11"
    } else if (D.ua.indexOf("edge") > -1) {
        a = "Edge"
    } else if (D.ua.indexOf("firefox") > -1) {
        a = "Firefox"
    } else if (D.ua.indexOf("opera") > -1) {
        a = "Opera"
    } else if (D.ua.indexOf("chrome") > -1) {
        a = "Chrome"
    } else if (D.ua.indexOf("safari") > -1) {
        a = "Safari"
    } else if (D.ua.indexOf("gecko") > -1) {
        a = "Gecko"
    } else {
        a = "Unknown"
    }
    D.bro = a;
    return a
};
Bas.sp = function(a) {
    if (D.woo == '1') {} else {
        const s = a.getAttribute("type").toLowerCase();
        if (s != "hidden") a.type = "tel"
    }
};
Bas.bv = function(m, c, d) {
    if (m.addEventListener) {
        m.addEventListener(c, d, false)
    } else if (m.attachEvent) {
        m.attachEvent('on' + c, d)
    }
};
Bas.th = function(z) {
    return z.replace(/[！-～]/g, function(s) {
        return String.fromCharCode(s.charCodeAt(0) - 0xFEE0)
    })
};
Bas.ol = function(r) {
    let x = 0;
    while (r) {
        x += r.offsetLeft;
        r = r.offsetParent
    }
    return x
};
Bas.av = function(h, y, b) {
    if (h.addEventListener) {
        h.addEventListener(y, b, false);
        D.xlisten = "1"
    } else if (h.attachEvent) {
        h.attachEvent('on' + y, b);
        D.xlisten = "2"
    }
};
Bas.cs = function(x) {
    let z = x;
    if (x != "") {
        const s = document.getElementsByClassName(x);
        if (s.length == 1) {
            if (s[0].id == "") s[0].id = x;
            else z = s[0].id
        }
    }
    return z
};
Bas.zh = function(c) {
    const a = "０１２３４５６７８９ー－‐―" + decodeURI("%E2%88%92");
    const f = "0123456789-----";
    let s = "";
    for (let u = 0; u < c.length; u++) {
        let y = c.charAt(u);
        const g = a.indexOf(y, 0);
        if (g >= 0) y = f.charAt(g);
        s += y
    }
    return s
};
Bas.ot = function(f, e) {
    let v = 0;
    if (e == "") return v;
    if (typeof jQuery != "undefined") {
        const t = jQuery("#" + e).offset();
        v = t.top
    } else {
        while (f) {
            v += f.offsetTop;
            f = f.offsetParent
        }
    }
    if (document.getElementById(e)) {
        const w = document.getElementById(e);
        const y = Math.floor((w.offsetHeight - 18) / 2) - 3;
        if (y >= 2) v += y
    }
    return v
};
Basis_mole = "1";
Zip.cs = function(q, f, s, u) {
    let z = q + f + s + u;
    if (S.lang == "EN") {
        z = u;
        if (s != "") z += (z == "") ? s : "," + s;
        if (f != "") z += (z == "") ? f : "," + f;
        if (q != "") z += (z == "") ? q : "," + q
    }
    return z
};
Zip.ad = function(c, r) {
    let n = "0";
    if (c.currentStyle) n = c.currentStyle[r];
    else if (getComputedStyle) {
        n = document.defaultView.getComputedStyle(c, '').getPropertyValue(r)
    }
    if (typeof n === "undefined") n = "1";
    let u = n;
    u = u.replace(/rem/g, '');
    u = u.replace(/em/g, '');
    if (n != u) n = (D.sphone != "") ? parseInt(u * 24) : parseInt(u * 12);
    return n
};
Zip.c2 = function() {
    Bas.es(S.aj);
    D.xzp = "";
    D.xzz = "";
    D.xpr = "";
    D.xci = "";
    D.xar = "";
    D.xad = ""
};
Zip.h = function(c, h, m) {
    if (h !== "") {
        const d = document.createElement('optgroup');
        d.label = h;
        for (let y = 0; y < m.length; y++) {
            const f = document.createElement('option');
            f.value = m[y]['c'];
            f.appendChild(document.createTextNode(m[y]['p']));
            f.selected = m[y]['s'];
            d.appendChild(f)
        }
        c.appendChild(d)
    }
};
Zip.gcall = function(q) {
    const f = S.keyda.length;
    if (f < 3) return;
    const s = S.keyda.substr(0, 3);
    let p = "";
    let b = "";
    let n = "";
    let k = "";
    let t = "";
    let y = "";
    let a = [];
    let h = 0;
    for (let m = 0; m < q.zip.length; m++) {
        const z = ("0000" + q.zip[m].d).slice(-4);
        if (m == 0) {
            p = t = q.zip[m].p;
            b = y = q.zip[m].c;
            n = q.zip[m].a
        } else {
            if (typeof q.zip[m].p == "undefined" || "") p = t;
            else {
                p = t = q.zip[m].p
            }
            if (typeof q.zip[m].c == "undefined" || "") b = y;
            else {
                b = Zip.p(q.zip[m].c, y);
                y = b
            }
            n = Zip.p(q.zip[m].a, n)
        }
        if (z != k && m != 0) {
            S.Sc[s + k] = {
                "zip": a,
                "s": h,
                "m": ""
            };
            a = [];
            h = 0
        }
        const r = s + "-" + z;
        const c = {
            "d": r,
            "p": p,
            "c": b,
            "a": n
        };
        a[h] = c;
        h++;
        k = z
    }
    if (h != 0) S.Sc[s + k] = {
        "zip": a,
        "s": h,
        "m": ""
    };
    if (S.nodb == "" && D.min <= f && f <= D.max) {} else if (S.nodb == "") return;
    else if (S.nodb != "" && f == 3) {
        S.Sc[S.keyda] = q;
        return
    } else if (S.nodb != "" && f != 7) return;
    let w = S.Sc[S.keyda];
    if (!w) {
        a = [];
        a[0] = {
            "d": S.keyda,
            "p": "8",
            "c": "",
            "a": "",
            "n": ""
        };
        w = {
            "zip": a,
            "s": "0",
            "m": ""
        };
        S.Sc[S.keyda] = w
    }
    return Zip.zipac(w)
};
Zip.c5 = function(x, p) {
    if (p == 1) {
        x.style.backgroundColor = D.ovr;
        x.style.fontSize = 120 + '%'
    } else {
        x.style.backgroundColor = D.bgc;
        x.style.fontSize = 100 + '%'
    }
};
Zip.s5 = function(n, v) {
    const nx = n.toUpperCase();
    for (let u = 0; u < v.length; u++) {
        const c = v[u].split(":");
        if (c.length != 2) alert(v[u] + "??pt");
        const e = c[0];
        const z = c[1].toUpperCase();
        if (nx.indexOf(z) > 0) {
            D.pt = "3";
            return e;
            break
        }
    }
    return n
};
Zip.u7 = function(d) {
    return function(evt) {
        d._moverun_ = false;
        S.movex = S.movey = "";
        d.style.backgroundColor = D.bgc;
        if (D.xzz != "" && document.getElementById(D.xzz)) {
            Bas.fc(document.getElementById(D.xzz))
        } else if (D.xzp != "" && document.getElementById(D.xzp)) {
            Bas.fc(document.getElementById(D.xzp))
        }
    }
};
Zip.chk = function(h) {
    D.xzp = D.p[h];
    D.xzz = D.q[h];
    D.xpr = D.r[h];
    D.xci = D.i[h];
    D.xar = D.e[h];
    D.xad = D.a[h];
    if (typeof D.f[h] != "undefined") D.focus = D.f[h];
    S.lang = D.lang;
    if (D.lang == "EN") {
        S.lang = D.lang
    } else if (D.welcart == "1") {
        if (D.xzp == "memberzipcode" || D.xzp == "customerzipcode" || D.xzp == "deliveryzipcode") {
            const w = document.getElementById(D.xad).value;
            if (w != "") {
                Zip.c2();
                return
            }
        }
        const d = D.xpr.replace(/pref/g, 'country');
        if (d != "" && document.getElementById(d)) {
            const g = document.getElementById(d).value;
            if (g != "JP") return
        }
    } else if (D.sysid == "WOOCOMMERCE" && (D.xzp == "billing_postcode" || D.xzp == "shipping_postcode")) {
        const k = D.xzp.replace(/postcode/g, 'country');
        if (k != "" && document.getElementById(k)) {
            const b = document.getElementById(k).value;
            if (b != "JP") return
        }
    }
    if (S.lang == "EN") {} else if (S.lang != "" && S.lang != "JP") return;
    const v = document.getElementById(D.xzp);
    let e = v.value;
    if (D.xzz != "" && document.getElementById(D.xzz)) e += document.getElementById(D.xzz).value;
    const r = Bas.cg(e);
    if (typeof Zip.zipaddr_debug === "function") Zip.zipaddr_debug();
    if (r == "!!!") Zip.tc(r);
    if (isNaN(r)) return;
    const t = r.length;
    if (S.nodb != "") {
        if (t == 3) {
            Zip.g(r);
            return
        } else if (t != D.max) return
    }
    S.pad = Zip.ad(v, "padding-top");
    if (D.rtrs == "1" && D.min < "7" && (t == 0 || t == 1)) {
        S.uln = r;
        D.n = Zip.lg(D.n);
        Zip.d8(D)
    } else if (D.min <= t && t <= D.max) Zip.g(r);
    else if (S.nodb == "" && t == 6) {
        Zip.g(r)
    }
};
Zip.r2 = function(b) {
    let y = new Array();
    for (let z = 0; z < b.length; z++) {
        const v = b[z].split(":");
        if (v.length != 2) alert(b[z] + "??pr");
        y[v[1]] = v[0]
    }
    return y
};
Zip._Gui = function(t) {
    if (Bas.sc(t)) {
        D.min = "5"
    }
};
Zip.t3 = function(z) {
    if (S.fid != "" && document.getElementById(S.fid)) {
        Zip.i3(S.fid);
        const k = document.getElementById(S.fid).tagName.toLowerCase();
        if (k == "select") Zip.o(S.fid, z, D.preftable)
    }
};
Zip.r5 = function(h) {
    let k = new Array();
    for (let a = 0; a < h.length; a++) {
        const n = h[a].split(":");
        if (n.length != 2) alert(h[a] + "??");
        const e = n[0];
        const t = (e.length > 0) ? e.substr(0, 1) : "";
        if ("0" <= t && t <= "9") {
            k[e] = n[1]
        }
    }
    return k
};
Zip.u5 = function(q) {
    return function(evt) {
        if (q._moverun_) {
            let b;
            let u;
            if (D.xlisten == "1") {
                b = evt.pageX - q._page_x_;
                u = evt.pageY - q._page_y_
            } else {
                evt.returnValue = false;
                b = document.documentElement.scrollLeft + evt.clientX - q._page_x_;
                u = document.documentElement.scrollTop + evt.clientY - q._page_y_
            }
            S.movex = q._offset_x_ + b;
            S.movey = q._offset_y_ + u;
            q.style.left = S.movex + "px";
            q.style.top = S.movey + "px";
            q.style.backgroundColor = D.bgm
        }
    }
};
Zip.u1 = function(c) {
    return function(evt) {
        if (!c._moverun_) {
            c._moverun_ = true;
            c._offset_x_ = c.offsetLeft;
            c._offset_y_ = c.offsetTop;
            if (D.xlisten == "1") {
                evt.preventDefault();
                c._page_x_ = evt.pageX;
                c._page_y_ = evt.pageY
            } else {
                evt.returnValue = false;
                c._page_x_ = document.documentElement.scrollLeft + evt.clientX;
                c._page_y_ = document.documentElement.scrollTop + evt.clientY
            }
            c.style.left = "0px";
            c.style.top = "0px";
            S.movex = c._offset_x_ - c.offsetLeft;
            S.movey = c._offset_y_ - c.offsetTop;
            c.style.left = S.movex + "px";
            c.style.top = S.movey + "px"
        }
    }
};
Zip.u9 = function(x, f) {
    if (f == 1) {
        x.style.backgroundColor = D.ovr;
        x.style.fontSize = 120 + '%'
    } else {
        x.style.backgroundColor = D.bgc;
        x.style.fontSize = 100 + '%'
    }
};
Zip.w_after = function(v, f) {
    jQuery(function($) {
        const c = $("input[name='delivery[delivery_flag]']:checked").val();
        if (c != "" && f != "") {
            orderfunc.make_delivery_date(($('#delivery_method_select option:selected').val() - 0))
        }
    })
};
Zip.o = function(t, u, z) {
    const r = Zip.r5(Zip.t1());
    const y = document.getElementById(t);
    const a = y.childNodes;
    for (let s = a.length - 1; s >= 0; s--) {
        if (a[s].nodeName == "OPTGROUP") {
            y.removeChild(a[s])
        }
    }
    const v = y.options.length - 1;
    for (let w = v; w >= 0; w--) {
        y.options[w] = null
    }
    y.options[0] = new Option(D.sl, D.sc);
    let k = 0;
    let m = 0;
    let n = new Array();
    let b = "";
    let h = "";
    for (let e = 0; e < z.length; e++) {
        const g = z[e].split(":");
        if (g.length != 2) alert(z[e] + "??");
        let q = g[0];
        let f = g[1];
        if (D.pn == "2" && q.length == 1) q = "0" + q;
        const x = (q.length > 0) ? q.substr(0, 1) : "";
        const d = (q.length >= 2) ? q.substr(1, 1) : "";
        if (x == "g" && ("0" <= d && d <= "9")) {
            if (f == "") {
                f = x_lin
            }
            Zip.h(y, b, n);
            b = f;
            n = new Array();
            m = 0
        } else if ("0" <= x && x <= "9") {
            k++;
            if (D.pt == "3" && r[q]) h = "JP_" + r[q];
            else if (D.pt == "2") h = f;
            else h = q;
            if (b !== "") {
                n[m] = new Array();
                n[m]['p'] = f;
                n[m]['c'] = h;
                n[m]['s'] = (Number(q) == Number(u)) ? true : false;
                m++
            } else {
                y.options[k] = new Option(f, S.pfc + h);
                if (Number(q) == Number(u)) y.options[k].selected = true
            }
        } else {
            k++;
            h = q;
            y.options[k] = new Option(f + "???", h + "???");
            if (Number(q) == Number(u)) y.options[k].selected = true
        }
    }
    Zip.h(y, b, n);
    if (D.sphone == "1" && D.eccube != "1") {
        try {
            $('#' + t).selectmenu('refresh')
        } catch (e) {
            alert('jQuery mobile is not defined.')
        }
    }
};
Zip.p = function(p, v) {
    let q = "";
    let f = 0;
    for (let a = 0; a < p.length; a++) {
        const t = p.substr(a, 1);
        if (f == 1 && "0" <= t && t <= "9") {
            q += v.substr(q.length, parseInt(t) + 3);
            f = 0
        } else if (t == "\t") f = 1;
        else q += t
    }
    return q
};
Zip.up = function(m) {
    let h = "";
    if (m.zip.length != 1) return h;
    const b = Zip.r5(Zip.t2());
    const t = m.zip[0].p;
    const w = m.zip[0].c;
    let u = m.zip[0].a;
    const p = m.zip[0].n;
    if (p == "") {} else if (p == "@") u = "";
    else u = p;
    const x = b[t] + w + u;
    let g = (D.xpr != "" && document.getElementById(D.xpr)) ? document.getElementById(D.xpr).value : "";
    const n = (D.xci != "" && document.getElementById(D.xci)) ? document.getElementById(D.xci).value : "";
    const d = (D.xar != "" && document.getElementById(D.xar)) ? document.getElementById(D.xar).value : "";
    const q = (D.xad != "" && document.getElementById(D.xad)) ? document.getElementById(D.xad).value : "";
    if (g != "") {
        let f = g.match(/\d/g);
        if (!f) f = "";
        if (f != "") {
            f = Number(f.join(""));
            for (let k = 0; k < D.preftable.length; k++) {
                const a = D.preftable[k].split(":");
                if (a.length != 2) alert(g + "???");
                if (a[0] == f) {
                    g = a[1];
                    break
                }
            }
        }
    }
    const e = g + n + d + q;
    const c = x.length;
    if (e.substr(0, c) == x) h = "equal";
    return h
};
Zip.cr = function() {
    document.getElementById(D.xzz).value = "";
    const d = document.getElementById(D.xzp);
    d.value = "";
    Bas.fc(d);
    Zip.c2()
};
Zip.d9 = function() {
    const y = document.getElementById(D.xzp);
    y.style.position = "relative";
    const x = Bas.ol(y) + D.left;
    const a = Bas.ot(y, D.xzp) + D.top + parseInt(S.pad) - 1;
    const h = Zip.s2();
    h.style.left = x + "px";
    h.style.top = a + "px";
    return h
};
Zip.csp = function() {
    let h = '#zip_header{color:{lnc};}';
    h += '#zip_body{width:270px; overflow:auto; padding:3px 0px 10px;}';
    h += '#zip_body a,#zip_count a{color:{lnc}; text-decoration:none; white-space:nowrap;}';
    h += '#zip_count{color:{lnc};}';
    h += '#zip_close a,#zip_footer a{color:{clr}; text-decoration:none; white-space:nowrap;}';
    return h
};
Zip.t2 = function() {
    const s = ["1:北海道", "2:青森県", "3:岩手県", "4:宮城県", "5:秋田県", "6:山形県", "7:福島県", "8:茨城県", "9:栃木県", "10:群馬県", "11:埼玉県", "12:千葉県", "13:東京都", "14:神奈川県", "15:新潟県", "16:富山県", "17:石川県", "18:福井県", "19:山梨県", "20:長野県", "21:岐阜県", "22:静岡県", "23:愛知県", "24:三重県", "25:滋賀県", "26:京都府", "27:大阪府", "28:兵庫県", "29:奈良県", "30:和歌山県", "31:鳥取県", "32:島根県", "33:岡山県", "34:広島県", "35:山口県", "36:徳島県", "37:香川県", "38:愛媛県", "39:高知県", "40:福岡県", "41:佐賀県", "42:長崎県", "43:熊本県", "44:大分県", "45:宮崎県", "46:鹿児島県", "47:沖縄県", "99:海外"];
    return s
};
Zip.njq = function(q, w) {
    if (D.wp == "2" && typeof jQuery != "undefined") {
        const u = q.id;
        jQuery(function($) {
            $("#" + u).val(w)
        })
    } else q.value = w
};

function Zps() {
    this.ver = "7";
    this.rev = ".251";
    this.pad = 0;
    this.aj = "autozip";
    this.mvn = "movable_zipaddr";
    this.zc = "zip_close";
    this.host = "PierreSoft";
    this.keydb = "";
    this.keyda = "";
    this.keydt = "";
    this.keydu = "";
    this.keydc = 0;
    this.highs;
    this.movex = "";
    this.movey = "";
    this.optgrp = "x";
    this.parm = "{host}";
    this.ip = "{ip}";
    this.kyn = "520abcpierre-softdef1234{keywd}";
    this.keyc = "{keyc}";
    this.mesg2 = "";
    this.url2 = "null";
    this.nodb = "2";
    this.opt = "@ZipAddr_";
    this.trc = "{trc}";
    this.fid = "";
    this.pfc = "";
    this.lang = "{lang}";
    this.Sc = [];
    this.uln;
    this.ul3;
    this.n
}
let S = new Zps;
Zip.as3 = function(m, b, r, p) {
    if (D.xzp == "") {
        return
    }
    const v = document.getElementById(b);
    v.style.position = "relative";
    v.noWrap = "true";
    let u;
    let e;
    if (S.movex == "") {
        u = Bas.ol(v) + D.left;
        e = Bas.ot(v, b) + D.top + parseInt(S.pad) - 1;
        if (S.keydu == "b") {
            S.keydc--;
            e += S.keydc * parseInt(S.highs)
        } else if (S.keydu == "a") {
            S.keydc++;
            e += S.keydc * parseInt(S.highs)
        }
    } else {
        u = S.movex;
        e = S.movey
    }
    if (D.sphone != "") {
        u -= 30
    }
    m.style.left = u + "px";
    m.style.top = e + "px";
    const k = Bas.er(S.mvn, m);
    k.style.cursor = 'move';
    k.innerHTML = r;
    m._moverun_ = false;
    if (D.sphone == "") {
        Bas.av(k, "mousedown", Zip.u1(m));
        Bas.av(document, "mouseup", Zip.u7(m));
        Bas.av(document, "mousemove", Zip.u5(m))
    }
};
Zip.g = function(e) {
    S.keydb = e;
    const q = e.split("@");
    S.keyda = q[0];
    S.keydt = S.keydu = "";
    if (q.length > 1) {
        S.keydt = "@";
        S.keydu = q[1]
    } else S.keydc = 0;
    S.ul3 = "zipaddr";
    let w = "";
    const h = location.host + "|" + location.hostname + "|" + S.parm + "|" + S.ip;
    const m = S.keyda.substr(0, 1);
    const r = S.keyda.length;
    const c = S.Sc[S.keydb];
    const k = S.Sc[S.keydb.substr(0, 3)];
    if (c && D.min <= r && r <= D.max) {
        return Zip.zipac(c)
    } else if (S.nodb == "" && r == 6) {
        const s = Bas.pr(unescape("j%u3044s/_%u3044c%u3042zi%u3044p" + S.ver + ".%u3044ph%u3044p" + "?k="));
        w = Zip.yu(D.sv) + "/" + s + encodeURI(e + "&u=" + h + "&c=" + D.contract + "&v=" + S.ver);
        w += "&s=" + S.host + "&d=" + D.sel + "&t=" + D.wok + "&n=" + S.kyn + "&w=" + S.keyc;
        S.uln = w
    } else if (S.nodb == "2") {
        const p = Bas.pr(unescape("g%u3042it%u3046hu%u3044b.i%u3042o"));
        w = 'https:/' + '/' + D.zipaddr + "." + p + "/zipdata3/" + m + "/zip";
        S.ul3 = w + S.keyda.substr(0, 3) + ".js";
        S.uln = w + S.keyda + ".js"
    } else if (S.nodb == "1") {
        D.sv = "1";
        w = Zip.yu(D.sv) + "/js/zipdata/" + m + "/zip";
        S.ul3 = w + S.keyda.substr(0, 3) + ".js";
        S.uln = w + S.keyda + ".js"
    } else return;
    if (S.nodb == "" && c && r == 6) {} else if (S.nodb != "" && k) Zip.gcall(k);
    else if (S.nodb == "") Bas.ca(S.uln);
    else if (S.nodb != "") Bas.ca(S.ul3)
};
Zip.at2 = function(h) {
    if (D.xzp == "") {
        return
    }
    const c = h.split("_");
    if (c.length < 4) return;
    const r = c[0];
    const k = c[1];
    let a = c[2];
    const u = c[3];
    if (c.length > 4) {
        const e = c[4];
        if (e == "") {} else if (e == "@") a = "";
        else a = e
    }
    let m = "";
    if (c.length > 5) {
        m = c[5].replace("丁目", "－");
        m = Bas.th(m)
    }
    const w_h = r + "_" + u + "_" + k + "_" + a + "_" + m;
    const b = r.split("-");
    Zip.i3(D.xpr);
    let z = "";
    if (S.lang == "" || S.lang == "JP") z = Zip.t2();
    else z = Zip.t1();
    z = Zip.r5(z);
    let w;
    if (D.sphone != "") {
        if (D.xzz != "" && document.getElementById(D.xzz)) w = document.getElementById(D.xzz);
        else w = document.getElementById(D.xzp);
        w.blur()
    }
    w = document.getElementById(D.xzp);
    const d = w.getAttribute("type").toLowerCase();
    if (D.xzz != "" && document.getElementById(D.xzz)) {
        w.value = b[0];
        document.getElementById(D.xzz).value = b[1]
    } else if (D.dli == "" || d == "number") {
        w.value = b[0] + b[1]
    } else {
        w.value = b[0] + D.dli + b[1]
    }
    let v = "";
    let q = "";
    if (D.xpr != "" && document.getElementById(D.xpr)) {
        q = document.getElementById(D.xpr);
        const t = q.tagName.toLowerCase();
        if (t == "select") Zip.o(D.xpr, u, D.preftable);
        else {
            if (z[u]) Zip.njq(q, z[u])
        }
    } else {
        if (z[u]) v = z[u]
    }
    let wu = v;
    let wk = k;
    let wa = a;
    let wm = m;
    if (D.xci != "" && document.getElementById(D.xci)) {
        q = document.getElementById(D.xci);
        if ((D.xar != "" && document.getElementById(D.xar)) || (D.xad != "" && document.getElementById(D.xad))) {
            Zip.njq(q, Zip.cs(wu, wk, "", ""))
        } else {
            Zip.njq(q, Zip.cs(wu, wk, wa, wm));
            Zip.fs(q)
        }
        wu = "";
        wk = ""
    } else if ((D.xar != "" && document.getElementById(D.xar)) || (D.xad != "" && document.getElementById(D.xad))) {} else alert('住所id名の定義がありません。');
    if (D.xar != "" && document.getElementById(D.xar)) {
        q = document.getElementById(D.xar);
        if (D.xad != "" && document.getElementById(D.xad)) {
            Zip.njq(q, Zip.cs(wu, wk, wa, ""))
        } else {
            Zip.njq(q, Zip.cs(wu, wk, wa, wm));
            Zip.fs(q)
        }
        wu = "";
        wk = "";
        wa = ""
    } else if (D.xad != "" && document.getElementById(D.xad)) {}
    if (D.xad != "" && document.getElementById(D.xad)) {
        q = document.getElementById(D.xad);
        Zip.njq(q, Zip.cs(wu, wk, wa, wm));
        Zip.fs(q)
    }
    const f = D.xzp;
    const n = D.xpr;
    Zip.c2();
    if ((S.opt.substr(0, 9) != "@ZipAddr_" || D.woo != "") && typeof woo_after === "function") {
        woo_after(f, w_h)
    }
    if (D.welcart == "1" && n == "delivery_pref") {
        const a8 = z[u];
        if (typeof jQuery == "undefined") {
            alert("welcart_SystemChanged")
        } else Zip.w_after(u, a8)
    }
    return false
};
Zip._Sub = function(f, c) {
    if (typeof D.mai != "undefined") D.mai = "1";
    if (Bas.sc(f)) {
        D.min = "7";
        Zip.chk(c)
    }
};
Zip.wf = function(w, d) {
    const u = "1.12";
    const g = d.split("_");
    const x = g[1];
    const q = Zip.t2();
    const c = Zip.r5(q);
    const h = c[x];
    let e = "";
    let y;
    let f;
    const k = "s2id_" + w.replace("postcode", "state");
    if (document.getElementById(k)) {
        y = document.getElementById(k);
        for (let b = 0; b < y.childNodes.length; b++) {
            f = y.childNodes[b];
            const r = f.nodeName.toUpperCase();
            if (r == "A") {
                for (let m = 0; m < f.childNodes.length; m++) {
                    const z = f.childNodes[m].nodeName.toUpperCase();
                    if (z == "SPAN" && f.childNodes[m].className == "select2-chosen") {
                        f.childNodes[m].innerHTML = h;
                        e = "1";
                        break
                    }
                }
            }
        }
    }
    if (e == "") {
        let t = "select2-chosen-";
        if (document.getElementById("select2-chosen-4")) {
            t += (w == "billing_postcode") ? "2" : "4"
        } else if (document.getElementById("select2-chosen-3")) {
            t += "3"
        } else if (document.getElementById("select2-chosen-5")) {
            t += "5"
        } else {
            t += (w == "billing_postcode") ? "1" : "2"
        }
        if (document.getElementById(t)) {
            f = document.getElementById(t);
            f.innerHTML = h
        } else if (document.getElementById(k)) {
            y = document.getElementsByClassName("chosen-single");
            for (let n = 0; n < y.length; n++) {
                f = y[n];
                if (f.parentNode.id == k) {
                    f.innerHTML = '<span>' + h + '</span><div><b></b></div>';
                    break
                }
            }
        }
    }
    if (typeof woocommerce_after_own === "function") {
        woocommerce_after_own(w, d)
    }
};
Zip.fs = function(w) {
    if (D.focus != "") {
        let k = D.focus;
        if (D.eccube == "1") {
            const d = D.xad.split("_");
            if (d.length == 2) k = d[0] + "_" + d[1].replace("addr01", "addr02")
        }
        Bas.gi(k);
        if (document.getElementById(k)) Bas.fc(document.getElementById(k))
    } else Bas.fc(w)
};
Zip.tc = function(g) {
    let p = "data:" + g + "\n";
    let c = new Array();
    c[0] = D.xzp;
    c[1] = D.xzz;
    c[2] = D.xpr;
    c[3] = D.xci;
    c[4] = D.xar;
    c[5] = D.xad;
    c[6] = D.focus;
    for (let f = 0; f < c.length; f++) {
        p += c[f] + ":";
        if (c[f] != "" && document.getElementById(c[f])) {
            p += "defined"
        }
        p += "\n"
    }
    alert(p)
};
Zip.d8 = function(n) {
    if (n.s == 0) {
        Zip.zipac(n);
        return
    }
    const f = n.n;
    let w = '<span id="' + S.zc + '"><span class="zip_line" style="color:' + D.lnc;
    w += '">&nbsp;' + f + '</span></span>';
    const y = Zip.d9();
    y.innerHTML = w;
    const e = document.getElementById(S.zc);
    Bas.av(e, 'mouseover', Zip.c2)
};
Zip.css = function() {
    let p = '#zip_header{color:{lnc};}';
    p += '#zip_body{width:270px; overflow:auto; padding:3px 0px 3px;}';
    p += '#zip_body a{color:{bgc}; text-decoration:none; white-space:nowrap; font-size:30px; display:block; position:relative; margin:5px 0; padding:0px 25px 0px 5px; border-radius:5px; background:#fff; font-weight:bold;}';
    p += '#zip_body a:after{display:block; content:""; position:absolute; top:50%; right:10px; width:6px; height:6px; border-top:solid 2px #093; border-right:solid 2px #093; -webkit-transform:rotate(45deg); transform:rotate(45deg);}';
    p += '#zip_count{color:{lnc}; white-space:nowrap; font-size:10px;}';
    p += '#zip_close a{color:{clr}; text-decoration:none; white-space:nowrap;}';
    p += '#zip_footer a{color:{clr}; text-decoration:none; white-space:nowrap; font-size:10px;}';
    return p
};
Zip.i3 = function(p) {
    const y = Zip.r2(Zip.t2());
    const s = Zip.t1();
    D.pt = "1";
    D.pn = "1";
    S.pfc = "";
    S.optgrp = "x";
    D.preftable = new Array();
    if (p != "" && document.getElementById(p)) {
        const u = document.getElementById(p);
        if (u.tagName.toLowerCase() == "select") {
            let z = 0;
            let q = 0;
            for (let g = 0; g < u.childNodes.length; g++) {
                const c = u.childNodes[g].nodeName.toUpperCase();
                if (c == "#TEXT") {} else if (c == "OPTION") {
                    let k = u.childNodes[g].value;
                    let r = u.childNodes[g].text;
                    if (k != "") {
                        let v = k.match(/\d/g);
                        if (!v) v = "";
                        if (v != "") v = v.join("");
                        if (v != "" && v != k) {
                            if (S.pfc == "") S.pfc = k.replace(v, "");
                            k = v
                        } else k = Zip.s5(k, s)
                    }
                    if (k == "") D.sl = r;
                    else if (k == "0") {
                        D.sl = r;
                        D.sc = k
                    } else {
                        let a = 1;
                        if (k == "1") D.pn = "1";
                        else if (k == "01") D.pn = "2";
                        else if (isNaN(k)) {
                            D.pt = "2";
                            if (y[k]) {
                                r = k;
                                k = y[k]
                            } else if (z < 1) {
                                D.sl = r;
                                D.sc = k;
                                D.pt = "1";
                                a = 0
                            } else {
                                r = k;
                                k = "99"
                            }
                        }
                        if (a == 1) {
                            D.preftable[z] = k + ":" + r;
                            z++
                        }
                    }
                } else if (c == "OPTGROUP") {
                    const n = u.childNodes[g].label;
                    D.preftable[z] = "g" + String(q) + ":" + n;
                    q++;
                    z++;
                    const h = u.childNodes[g];
                    for (let d = 0; d < h.childNodes.length; d++) {
                        const m = h.childNodes[d].nodeName.toUpperCase();
                        if (m == "#TEXT") {} else if (m == "OPTION") {
                            let f = h.childNodes[d].value;
                            const w = h.childNodes[d].text;
                            if (f == "1") D.pn = "1";
                            else if (f == "01") D.pn = "2";
                            else if (isNaN(f)) {
                                D.pt = "2";
                                f = y[f]
                            }
                            D.preftable[z] = f + ":" + w;
                            z++
                        }
                    }
                }
            }
            if (S.optgrp == "x") S.optgrp = ""
        }
    }
    if (D.preftable.length == 0) D.preftable = Zip.t2()
};
Zip.zipac = function(q) {
    if (typeof D.mai != "undefined" && D.mai == "1") {
        D.mai = "";
        D.min = "8"
    }
    if (D.xzp == "") return;
    S.Sc[S.keydb] = q;
    Zip.i3(D.xpr);
    const a = Zip.up(q);
    if (a != "") {
        Zip.c2();
        return
    }
    if (D.guide.indexOf("@zipaddr", 0) <= 0) return;
    S.opt = (S.mesg2 == "") ? '@ZipAddr_V' + D.xvr : S.mesg2;
    Bas.es(D.elid);
    if (q.s == 0) {} else if (S.keydt == "@") {} else if (q.zip.length == 1 && D.rtrv != "1" && S.keyda.length != 7) {} else if (q.zip.length == 1) {
        let c = q.zip[0].d + "_" + q.zip[0].c + "_" + q.zip[0].a + "_" + q.zip[0].p + "_";
        if (typeof q.zip[0].u != "undefined") c += "_" + q.zip[0].u;
        Zip.at2(c);
        return
    }
    let s = "";
    let v = "";
    let h = "";
    if (q.s == 0) {} else {
        let t = "";
        if (S.lang == "" || S.lang == "JP") t = Zip.t2();
        else t = Zip.t1();
        t = Zip.r5(t);
        const n = q.zip[0].d.substr(0, 3);
        const w = q.zip[0].c;
        const f = q.zip[0].p;
        const p = t[f];
        s = '<span id="zip_header">' + D.mrk + n + '&nbsp;[' + Zip.cs(p, w, "", "") + ']</span>';
        let g = Zip.Hs(q, t);
        if (D.opt[0] == "1") g = '<ul>' + g + '</ul>';
        v = '<div id="zip_body">' + g + '</div>'
    }
    let k = q.m;
    if (q.m == "") {
        k = (D.sv == "0") ? "V" : D.sv;
        k = '@ZipAddr_' + k + D.xvr
    }
    let x = (typeof S.mesg2 == "undefined") ? "" : S.mesg2;
    if (x != "") k = x;
    if (typeof zipaddr_nodisplay === "function") {
        const e = zipaddr_nodisplay();
        if (Bas.sc(e)) x = "skip"
    }
    S.opt = k;
    let b = (typeof S.url2 == "undefined") ? "" : S.url2;
    if (b == "" || b == "null") b = D.help;
    const d = (D.xzz != "" && document.getElementById(D.xzz) && D.sphone == "" && q.s == 0) ? "1" : "";
    let r = '<span id="zip_count">' + q.s + Zip.lg("件ヒット");
    if (d == "1") r += ' <a href="#" onClick="Zip.cr();return false;">[クリア]</a>　';
    r += '</span>';
    let u = '<span id="' + S.zc + '"><a href="#" onClick="Zip.c2();return false;"';
    if (D.sphone == "") u += ' onMouseOver="Zip.c5(this,1);" onMouseOut="Zip.c5(this,0);"';
    u += '>&nbsp;[' + Zip.lg("閉じる") + ']</a></span>';
    const z = (x == "skip") ? "" : '<span id="zip_footer"><a href="' + b + '" target="_blank">' + k + '</a></span>';
    const y = D.guide.replace(/NL/g, "<br />");
    let m;
    if (D.sphone == "") m = Zip.csp();
    else m = Zip.css();
    m = m.replace(/{lnc}/g, D.lnc);
    m = m.replace(/{bgc}/g, D.bgc);
    m = m.replace(/{clr}/g, D.clr);
    m = '<style type="text/css">' + m + '</style>' + y;
    m = m.replace("@head", s);
    m = m.replace("@page", h);
    m = m.replace("@line", v);
    m = m.replace("@count", r);
    m = m.replace("@close", u);
    m = m.replace("@zipaddr", z);
    m = m.replace("<br /><br />", "<br />");
    m = m.replace(/&nbsp;+$/, "");
    if (q.s == 0) {
        m = m.replace("<br />", "");
        m = m.replace(/&nbsp;/g, "")
    }
    const b2 = Zip.s2();
    b2.innerHTML = "";
    Zip.as3(b2, D.xzp, m, "1")
};
Zip.Hs = function(n, p) {
    let x = "";
    const t = n.zip[0].c;
    const g = n.zip[0].p;
    let v = "";
    let k = "";
    let m = "";
    for (let y = 0; y < n.zip.length; y++) {
        if (y == 0) {
            v = n.zip[y].d;
            k = n.zip[y].c;
            m = n.zip[y].a
        } else {
            v = Zip.p(n.zip[y].d, v);
            k = Zip.p(n.zip[y].c, k);
            m = Zip.p(n.zip[y].a, m)
        }
        const e = v + "_" + k + "_" + m + "_" + n.zip[y].p + "_";
        let s = '<font size="2">' + v.substr(4) + "</font>";
        s = (D.sphone == "") ? "&nbsp;&nbsp;" + s + " " : s;
        if (g != n.zip[y].p) {
            s += p[n.zip[y].p] + k
        } else if (D.design == "1" && k == t) {} else s += k;
        s += m;
        let a = '<a href="#" onClick="return Zip.at2(' + "'" + e + "'" + ');"';
        if (D.sphone == "") a += ' onMouseOver="Zip.u9(this,1);" onMouseOut="Zip.u9(this,0);"';
        a += '>' + s + '</a>';
        if (D.opt[0] == "1") a = '<li>' + a + '</li>';
        else if (x != "" && D.sphone == "") x += '<br />';
        x += a
    }
    return x
};
Zip.t1 = function() {
    const h = ["1:Hokkaido", "2:Aomori", "3:Iwate", "4:Miyagi", "5:Akita", "6:Yamagata", "7:Fukushima", "8:Ibaraki", "9:Tochigi", "10:Gunma", "11:Saitama", "12:Chiba", "13:Tokyo", "14:Kanagawa", "15:Nigata", "16:Toyama", "17:Ishikawa", "18:Fukui", "19:Yamanashi", "20:Nagano", "21:Gifu", "22:Shizuoka", "23:Aichi", "24:Mie", "25:Shiga", "26:Kyoto", "27:Osaka", "28:Hyogo", "29:Nara", "30:Wakayama", "31:Tottori", "32:Shimane", "33:Okayama", "34:Hiroshima", "35:Yamaguchi", "36:Tokushima", "37:Kagawa", "38:Ehime", "39:Kochi", "40:Fukuoka", "41:Saga", "42:Nagasaki", "43:Kumamoto", "44:Oita", "45:Miyazaki", "46:Kagoshima", "47:Okinawa"];
    return h
};
Zip.s2 = function() {
    const r = Bas.er(S.aj, "");
    r.style.position = 'absolute';
    r.style.display = "block";
    r.style.zIndex = "999999";
    const a = (D.sphone != "") ? D.sfon : D.pfon;
    const n = (D.sphone != "") ? D.shig : D.phig;
    S.n = a;
    r.style.fontFamily = D.family;
    r.style.fontSize = a + 'px';
    r.style.lineHeight = n;
    r.style.padding = "5px 8px";
    r.style.borderRadius = "8px";
    r.style.backgroundColor = D.bgc;
    r.style.textAlign = 'left';
    if (D.fweight != "") {
        r.style.fontWeight = D.fweight
    }
    return r
};
Zip.w0 = function() {};
Zip.lg = function(w) {
    if (S.lang == "" || S.lang == "JP") return w;
    if (D.Chngt[w]) return D.Chngt[w];
    else return ""
};