/*
 * zutomayo.net
 * update 2021.6.24
 */
(function($) {
    function isSmartPhone() {
        if (navigator.userAgent.match(/iPhone|Android.+Mobile/)) {
            return true;
        } else {
            return false;
        }
    }

    function isiOS() {
        if (navigator.userAgent.match(/iPhone|iPad/)) {
            return true;
        } else {
            return false;
        }
    }

    //--------------------------------------------------
    //
    //  TopAnim トップ表示アニメーション
    //
    //--------------------------------------------------
    var TopAnim = (function() {

        const topObj = $("#articletop");
        const _menu = topObj.find(".ztmy-top--nav li a span");
        const _news = topObj.find(".ztmy-top--news");
        const _mv = topObj.find(".ztmy-top--mv");
        // const _rule = CSSRulePlugin.getRule(".ztmy-top--nav li a:before");

        return {
            Init: function(url) {


                const tl = gsap.timeline();

                // tl.staggerTo(_rule, 0.3, {cssRule: {width: "100%"},delay: 0.5,stagger: 0.3});
                // tl.staggerTo(_rule, 0.2, {cssRule: {left: "100%",width:0},delay: 0.2,stagger: 0.3});
                gsap.to(_menu, 0.2, {
                    width: "100%",
                    delay: 1,
                    stagger: 0.1,
                    ease: Power2.easeInOut
                });



                if (isSmartPhone()) {
                    gsap.to(_news, 0.5, {
                        opacity: 1,
                        scale: 1,
                        delay: 0.5,
                        stagger: 0.3,
                        ease: Sine.easeOut
                    });
                } else {
                    gsap.to(_news, 0.5, {
                        opacity: 1,
                        scale: 1.5,
                        delay: 0.5,
                        stagger: 0.3,
                        ease: Sine.easeOut
                    });
                }

                gsap.to(_mv, 1, {
                    right: 25,
                    delay: 2.5,
                    ease: Power2.Back
                });

                // var tl = gsap.timeline({ repeat: -1, yoyo: true });

                // tl.staggerTo(_rule, 1, {
                //   cssRule: { left: 100 },
                //   ease: Power2.easeInOut
                // }, 0.5);



            }
        }
    })();

    //--------------------------------------------------
    //
    //  ModalContents　モーダル
    //
    //--------------------------------------------------
    var ModalContents = (function() {


        const arrowWidth = 40; //矢印ボタンのwidth
        const arrowGap = 20; //矢印ボタンとポップアップコンテナの距離





        return {
            Init: function() {

                if ($('.ztmy-photo-popup').length) {
                    //classが存在したら実行する
                    $('.ztmy-photo-popup').magnificPopup({
                        delegate: 'a',
                        type: 'image',
                        gallery: {
                            enabled: true,
                            arrowMarkup: '<span role="button" class="gallery-arrow gallery-arrow-%dir%"></span>'
                        },
                        callbacks: {
                            change: function() {
                                ModalContents.galleryArrowPosition();
                            },
                            resize: function() {
                                ModalContents.galleryArrowPosition();
                            },
                            open: function() {
                                ModalContents.galleryArrowPosition();
                            }
                        }
                    });
                }

            },
            //矢印の配置を調整する関数
            galleryArrowPosition: function() {
                const contWidth = $('.mfp-content').width(); // .mfp-contentのwidth取得
                const left = contWidth / 2 + arrowGap + arrowWidth - 6; //「前へ」ボタンの調整量
                const right = contWidth / 2 + arrowGap - 6; //「次へ」ボタンの調整量
                // $('.gallery-arrow-left').css('margin-left', '-' + left + 'px');
                // $('.gallery-arrow-right').css('margin-left', right + 'px');
            }
        }

    })();

    //--------------------------------------------------
    //
    //  ImageProtect　画像保存禁止
    //
    //--------------------------------------------------
    var ImageProtect = (function() {

        return {
            Init: function(url) {

                if (document.URL.match(url)) {
                    document.oncontextmenu = function() {
                        return false;
                    };
                    document.body.oncontextmenu = "return false;"
                    document.onselectstart = function() {
                        return false;
                    };
                    document.onmousedown = function() {
                        return false;
                    };
                    document.body.onselectstart = "return false;"
                    document.body.onmousedown = "return false;"
                }

            }
        }
    })();


    //--------------------------------------------------
    //
    //  SmoothScroll スムーススクロール
    //
    //--------------------------------------------------
    var SmoothScroll = (function() {

        return {
            Init: function(url) {

                $('a[href^="#"].smoothscroll').on("click", function(e) {
                    e.preventDefault();
                    var speed = 500;
                    var href = $(this).attr("href");
                    var target = $(href == "#" || href == "" ? 'html' : href);
                    var position = target.offset().top;
                    // console.log(position);
                    $('body,html').animate({
                        scrollTop: position
                    }, speed, 'swing');
                    return false;
                });
            }
        }
    })();


    //--------------------------------------------------
    //
    //  TopMvFunc トップのYoutube
    //
    //--------------------------------------------------
    var TopMvFunc = (function() {

        let _count = 0;
        return {
            Init: function() {

                $("#btnPlay").on('click', function() {
                    _count++;
                    console.log(_count);
                    TopMvFunc.Open();
                    if (_count > 13) {
                        _count = 0;
                        glitchEffect.Init();
                    }
                });
            },
            Open: function() {

                $('#player').parent().toggleClass("open");
            }
        }
    })();

    //--------------------------------------------------
    //
    //  TopicsMore ニュースの開封
    //
    //--------------------------------------------------
    var TopicsMore = (function() {

        return {
            Init: function() {

                $(".btn-news-more").on('click', function(e) {
                    $(this).parent().prev().addClass("full");
                    $(this).fadeOut(150);
                    e.preventDefault();
                    // TopicsMore.Open(this);
                });
                // },
                // Open: function(this){

                // $(this).prev.addClass("full");
            }
        }
    })();

    //--------------------------------------------------
    //
    //  ContentsMore もっと見る
    //
    //--------------------------------------------------
    var ContentsMore = (function() {

        return {
            Init: function() {

                /* ここには、表示するリストの数を指定します。 */
                var firstNum = 18;
                var moreNum = 18;

                /* 表示するリストの数以降のリストを隠しておきます。 */
                $('.ztmy-photo-cont:nth-child(n + ' + (firstNum + 1) + ')').addClass('is-hidden');




                // var _this = this;

                // $('.ztmy-photo-thumb').each(function(key, value){
                //    var tmp = $(value).find('img');
                //    $(tmp).on("load",onload());
                // });


                // function onload(data){
                //    console.log("load all complete");
                //    console.log(data);
                // }








                $(window).bind("scroll", function() {
                    scrollHeight = $(document).height();
                    scrollPosition = $(window).height() + $(window).scrollTop();
                    if ((scrollHeight - scrollPosition) / scrollHeight <= 0.05) {
                        //スクロールの位置が下部5%の範囲に来た場合
                        // console.log("一番下");
                        $('.ztmy-photo-cont.is-hidden').slice(0, moreNum).removeClass('is-hidden');
                        if ($('.ztmy-photo-cont.is-hidden').length == 0) {
                            $('.btn-more--photo').fadeOut(150);
                        }
                    } else {
                        //それ以外のスクロールの位置の場合
                        // console.log("それいがい");
                    }
                });

                // $(window).scroll(function () {
                //   var _winH = $(window).height();
                //   var _winInnerH = $(window).innerHeight();
                //   var _bottomPos = $(".ztmy-footer").offset().top;
                //   var _diffH = _bottomPos - _winH;
                //   var _scroll = $(this).scrollTop();
                //   console.log(_winH+" : "+_winInnerH+" : "+_scroll);
                //   if(_winH < _scroll){
                //     $('.ztmy-photo-cont.is-hidden').slice(0, moreNum).removeClass('is-hidden');
                //   }
                // });




                /* 全てのリストを表示したら「もっとみる」ボタンをフェードアウトします。 */
                $('.btn-more--photo').on('click', function() {
                    $('.ztmy-photo-cont.is-hidden').slice(0, moreNum).removeClass('is-hidden');
                    if ($('.ztmy-photo-cont.is-hidden').length == 0) {
                        $('.btn-more--photo').fadeOut(150);
                    }
                });

                // /* リストの数が、表示するリストの数以下だった場合、「もっとみる」ボタンを非表示にします。 */
                // $(function() {
                //   var list = $(".list li").length;  
                //     if (list < moreNum) {
                //       $('.btn-more').addClass('is-btn-hidden');
                //   }
                // });
            },
            Open: function() {

            }
        }
    })();

    //--------------------------------------------------
    //
    //  ContentsMore2 もっと見る（全部オープン）
    //
    //--------------------------------------------------
    var ContentsMore2 = (function() {

        let newsOpen = false;
        return {
            Init: function() {

                /* ここには、表示するリストの数を指定します。 */
                var firstNum = 1;
                var moreNum = 9999;

                /* 表示するリストの数以降のリストを隠しておきます。 */
                $('.ztmy-detail-list:nth-child(n + ' + (firstNum + 1) + ')').addClass('is-hidden');

                /* 全てのリストを表示したら「もっとみる」ボタンをフェードアウトします。 */
                $('.btn-more').on('click', function() {
                    if (!newsOpen) {
                        $('.ztmy-detail-list.is-hidden').removeClass('is-hidden');
                        $(this).addClass("on");
                        newsOpen = true;
                    } else {
                        $('.ztmy-detail-list').slice(1, moreNum).addClass('is-hidden');
                        // $('.ztmy-detail-list').addClass('is-hidden');
                        $(this).removeClass("on");
                        newsOpen = false;
                    }
                    // if ($('.ztmy-detail-list.is-hidden').length == 0) {
                    //   $('.btn-more').fadeOut(150);
                    // } 
                });

                // /* リストの数が、表示するリストの数以下だった場合、「もっとみる」ボタンを非表示にします。 */
                // $(function() {
                //   var list = $(".list li").length;  
                //     if (list < moreNum) {
                //       $('.btn-more').addClass('is-btn-hidden');
                //   }
                // });
            },
            Open: function() {

            }
        }
    })();

    //--------------------------------------------------
    //
    //  SS GOODS popup
    //
    //--------------------------------------------------

    $('.gallery-photo').each(function() {
        $(this).magnificPopup({
            delegate: 'a',
            type: 'image',
            removalDelay: 200,
            gallery: {
                enabled: true
            }
        });
        $('.gallery-photo').on('click', function() {
            $(this).next().fadeIn();
            $(this).parent().addClass("gallery-show");
            $(this).next().insertAfter(".mfp-content .mfp-figure");
            // $(".mfp-content figure").append($(this).next());

        });
        $(document).click(function() {
            var a = $(event.target).closest('.mfp-arrow,.gallery-photo').length;
            if (a) {
                // alert("Hogeをクリックしました");
            } else {
                // alert("Hoge以外をクリックしました");
                $('.gallery-txt').hide();
                $(".mfp-content .gallery-txt").insertAfter(".gallery-show .gallery-photo");
                $(".gallery-photo").parent().removeClass("gallery-show");
            }
        });
    });


    //--------------------------------------------------
    //
    //  HamburgerMenu ハンバーガーメニュー
    //
    //--------------------------------------------------
    var HamburgerMenu = (function() {

        return {
            Init: function() {

                document.getElementById('ztmy-burger').addEventListener('click', function() {
                    HamburgerMenu.Open();
                });
                $('.ztmy-header-menu a[href]').on('click', function(event) {
                    $('#ztmy-burger').trigger('click');
                });

            },
            Open: function() {
                document.getElementById('ztmy-burger-1').classList.toggle('ztmy-burger-1');
                document.getElementById('ztmy-burger-2').classList.toggle('ztmy-burger-2');
                document.getElementById('ztmy-burger-3').classList.toggle('ztmy-burger-3');
                document.getElementById('ztmy-header').classList.toggle('ztmy-header-in');

                $("body").toggleClass("header_open");
            }
        }
    })();
    //--------------------------------------------------
    //
    //  Pagetop ページトップ
    //
    //--------------------------------------------------
    var PageTop = (function() {

        return {
            Init: function() {

                var appear = false;
                var pagetop = $('#page_top');
                $(window).scroll(function() {

                    // console.log($(this).scrollTop() +"|"+$(".ztmy-footer").offset().top);

                    if ($(this).scrollTop() > ($(".ztmy-footer").offset().top - $(window).innerHeight())) {
                        appear = true;
                        pagetop.stop().animate({
                            'bottom': '150px' //下から50pxの位置に
                        }, 300); //0.3秒かけて現れる
                    } else if ($(this).scrollTop() > 800) { //100pxスクロールしたら
                        // if (appear == false) {
                        appear = true;
                        pagetop.stop().animate({
                            'bottom': '70px' //下から50pxの位置に
                        }, 300); //0.3秒かけて現れる
                        // }
                    } else {
                        if (appear) {
                            appear = false;
                            pagetop.stop().animate({
                                'bottom': '-200px' //下から-50pxの位置に
                            }, 300); //0.3秒かけて隠れる
                        }
                    }
                });
                // pagetop.click(function () {
                //   $('body, html').animate({ scrollTop: 0 }, 500); //0.5秒かけてトップへ戻る
                //   return false;
                // });


            }
        }
    })();
    //--------------------------------------------------
    //
    //  WindowDraggble DOMドラッグ
    //
    //--------------------------------------------------
    var WindowDraggble = (function() {

        let _mode = false;
        return {
            Init: function(url) {



                //要素の取得
                var elements = document.getElementsByClassName("drag-and-drop");

                //要素内のクリックされた位置を取得するグローバル（のような）変数
                var x;
                var y;

                //マウスが要素内で押されたとき、又はタッチされたとき発火
                for (var i = 0; i < elements.length; i++) {
                    elements[i].addEventListener("mousedown", mdown, false);
                    elements[i].addEventListener("touchstart", mdown, false);
                }

                //マウスが押された際の関数
                function mdown(e) {
                    _mode = true;
                    //クラス名に .drag を追加
                    this.classList.add("drag");

                    //タッチデイベントとマウスのイベントの差異を吸収
                    if (e.type === "mousedown") {
                        var event = e;
                    } else {
                        var event = e.changedTouches[0];
                    }

                    //要素内の相対座標を取得
                    x = event.pageX - this.offsetLeft;
                    y = event.pageY - this.offsetTop;

                    //ムーブイベントにコールバック
                    document.body.addEventListener("mousemove", mmove, false);
                    document.body.addEventListener("touchmove", mmove, false);
                }

                //マウスカーソルが動いたときに発火
                function mmove(e) {

                    //ドラッグしている要素を取得
                    var drag = document.getElementsByClassName("drag")[0];

                    //同様にマウスとタッチの差異を吸収
                    if (e.type === "mousemove") {
                        var event = e;
                    } else {
                        var event = e.changedTouches[0];
                    }

                    //フリックしたときに画面を動かさないようにデフォルト動作を抑制
                    e.preventDefault();

                    //マウスが動いた場所に要素を動かす
                    drag.style.top = event.pageY - y + "px";
                    drag.style.left = event.pageX - x + "px";

                    //マウスボタンが離されたとき、またはカーソルが外れたとき発火
                    drag.addEventListener("mouseup", mup, false);
                    document.body.addEventListener("mouseleave", mup, false);
                    drag.addEventListener("touchend", mup, false);
                    document.body.addEventListener("touchleave", mup, false);

                }

                //マウスボタンが上がったら発火
                function mup(e) {

                    var drag = document.getElementsByClassName("drag")[0];

                    //ムーブベントハンドラの消去
                    document.body.removeEventListener("mousemove", mmove, false);
                    if (drag) {
                        drag.removeEventListener("mouseup", mup, false);
                    }
                    document.body.removeEventListener("touchmove", mmove, false);
                    if (drag) {
                        drag.removeEventListener("touchend", mup, false);
                    }

                    //クラス名 .drag も消す
                    if (drag) {
                        drag.classList.remove("drag");

                    }
                    _mode = false;

                }


                $('.btn-close,.btn-no').on('click', function(e) {
                    mup();
                    WindowDraggble.Close($(this).data('close'));
                    e.preventDefault();
                });

                $('.btn-close-menu,.header-bar').on('click', function(e) {
                    mup();
                    WindowDraggble.Mini($(this).data('close'));
                    e.preventDefault();
                });

                $(".drag-and-drop a").on('click', function() {
                    mup();
                });


                // $("#spNews").on('touchend',function(){
                //   WindowDraggble.Mini("#spNews");
                // });

            },
            Close: function(target) {
                console.log(target);
                // $(target).addClass("windowclose");
                $(target).fadeOut(150);
            },
            Mini: function(target) {
                console.log(target);
                // $(target).addClass("windowclose");
                $(target).toggleClass("windowmini");
            }
        }
    })();


    //--------------------------------------------------
    //
    //  glitchEffect トップエフェクト
    //
    //--------------------------------------------------
    var glitchEffect = (function() {


        const _gif = $(".bugresult_image_gif");


        const _prof_pict = [
            "/themes/zutomayo/_assets/img/chara/chara-01.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-02.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-03.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-04.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-05.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-06.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-07.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-08.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-09.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-10.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-11.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-12.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-13.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-14.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-15.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-16.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-17.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-18.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-19.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-20.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-21.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-22.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-23.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-24.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-25.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-26.jpg",
            "/themes/zutomayo/_assets/img/chara/chara-27.jpg",
        ];
        const _prof_name = [
            "にらちゃん",
            "うにぐりくん",
            "グレイくん",
            "みみかゆし",
            "柿原 栗ムント",
            "しゃくま男",
            "木っ手男",
            "グレイヌ",
            "灰版電機工業(株)",
            "ナナシ",
            "NAGA",
            "あやつら",
            "アフロ☆サムライ",
            "ハカセ",
            "バクさん",
            "しゃっくりの応援団員",
            "襟頭の方",
            "宇宙人ストリングス",
            "ロボタ",
            "しゃくま界のドン",
            "インクねこ",
            "グレイの仮の姿",
            "ふらんけん",
            "ストライプ師匠",
            "ちりとり男",
            "シャミィ(ピギーワン)",
            "はさみ"
        ];
        const _prof_text = [
            "ほぼ主人公。<br>インナーカラー髪が特徴の女の子。戦いがち。<br>好物：ゲーム、肉まん、燻製、厚底、コスプレ<br>苦手：ゲーム、ドリフト(紫)、冬の赤マス",
            "蝶ネクタイのハリネズミ♂<br>マスコット的存在。皆勤賞。<br>好物：たけのこごはん、電化製品の温もり、秋<br>苦手：5メートル走、焚火、ミッキーマウス",
            "銀髪の男の子。<br>運命を背負いがち。<br>好物：苔、スコップ、立ち入り禁止区域<br>苦手：地図、インナージョーク、レバニラ炒め",
            "頭にリボンのハリネズミ♀ <br>レアキャラ。<br>好物：ラズベリー、桃味の炭酸水、ソロキャンプ<br>苦手：爪切り、グルテン、グレイくん",
            "黒いマントを着た人外。奪いがち。首を右に傾げたときは要注意。実は踊りがち。<br>好物：人間の温もり、金箔、イチョウの葉<br>苦手：トマト、ピアノソロ、早起き",
            "独自のエクササイズで大人気。<br>毎日スーツで出勤。クローンを持つ。<br>好物：室外機、紫色、止まれみよ<br>苦手：笛ラムネ、カラス、deleteボタン",
            "食いしん坊。相槌の打ちすぎで首が太くなった。今はこの世にいない。<br>好物：卵かけご飯、長電話、インクねこ<br>苦手：肥料、長風呂、話を先に終わらせること",
            "猟犬。へビースモーカー。<br>煙草はPeaceを愛用中。<br>好物：焚火、工場の煙、チキン<br>苦手：散髪、電池交換、歯磨き",
            "??????????????",
            "ニラメイドに育てられた女の子。<br>右耳にピアス。<br>好物：ロボタバイクでニラとツーリング<br>苦手：観覧車、メリーゴーランド、地球",
            "猫背で赤い頭と爪が特徴。戦闘モード高め。<br>好物：うに軍艦、登録者数10万人の盾<br>苦手：思い出、焚火、50メートル走",
            "友だち?。シャベルカー乗れるやつ。<br>メガネかけてるやつ。<br>好物：漫画、実家のカレー、都市伝説<br>苦手：挨拶、グループLINE、にら",
            "書道家。呪文などを巻物にしたためている。<br>好物：ダンス、パイプ煙草、ディスコ<br>苦手：書斎の片付け、美容室、ハタタテハゼ",
            "何か重要な役割を担っている。<br>監視している…？<br>好物：解剖学、古いカメラ、水仙の花<br>苦手：こども、スコップ、加工肉",
            "情緒不安定。触り心地はふわふわ。<br>好物：ハット、ピアノ速弾き、映画鑑賞<br>苦手：洗濯バサミ、アールグレイの紅茶、血",
            "しゃっくりで応援。騒動が好き。<br>左上：白目とけとろ 右：二つ目マカロン<br>左下：つまみ箱ロボ",
            "家事使用人頭。<br>なんでも見えるし聞こえる。<br>好物：ティーカップ、お洗濯、VHS収集<br>苦手：ねじ、裁縫針、髪の毛",
            "たまにメーゲンビーム刺す。実は傷つきやすい。<br>好物：ハッキング、エゴサ、しゃもじ<br>苦手：重力、同調圧力、じゃんけん",
            "ニラやナナシを見守る。ロボタバイクにも。<br>好物：鹿、首都高、内部クリーン<br>苦手：砂利道、汗水、充電1%",
            "しゃくま男を裏で牛耳っている。<br>好物：モンブラン、日本酒、DJイベント<br>苦手：学校の階段、カラス、警察",
            "気持ち次第でサイズが変わる。<br>動くとたまにインクが飛び散る。<br>好物：爪研ぎ、木っ手男、昼寝<br>苦手：歯磨き、シャワー、こちょこちょ",
            "猫耳パーカーを着て正体を隠す。<br>好物：苔、スコップ、立ち入り禁止区域<br>苦手：地図、インナージョーク、レバニラ炒め",
            "涙が黄色く光る。熱がこもりやすい。<br>好物：ロウソク、月、火の粉<br>苦手：暗闇、矢印、人混み",
            "和服を着た人外。踊りがち。<br>好物：振付、公衆電話、DAIGOダンス<br>苦手：空中戦、飛行機、ボーダー",
            "カラスでありウェイター。キーバード。<br>好物：ミルクとコンクリートのカルボナーラ、<br>はさみ、夜中の出勤日、DJ<br>苦手：太陽、食器洗い、黄ニラ",
            "友情出演<br>ユエズはお休み。",
            "魔。すれ違い。別れ。卒業。<br>どうにもならないこと。またはそのさま。<br>好物：髪、紙、チョキ<br>苦手：ペンチ、爪切り、蟹<br>",

        ];
        return {
            Init: function() {


                // $(".ztmy-footer-copy").on("click",function(){
                //   console.log("aaaa");
                html2canvas(document.getElementById("ztmy"), {
                    onrendered: function(canvas) {
                        var imgData = canvas.toDataURL();
                        document.getElementById("bugresult").src = imgData;


                        console.log("glitch start");
                        var ctx = canvas.getContext('2d');
                        var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);


                        const glitchParams = {
                            seed: Math.round(Math.random() * 99), // integer between 0 and 99
                            quality: Math.round(Math.random() * 99), // integer between 0 and 99
                            amount: Math.round(Math.random() * 99), // integer between 0 and 99
                            iterations: Math.round(Math.random() * 99) // integer
                        };
                        glitch(glitchParams)
                            .fromImageData(imageData)
                            .toDataURL()
                            .then(function(dataURL) {
                                var glitchedImg = new Image();
                                glitchedImg.src = dataURL;
                                // document.body.appendChild( glitchedImg );
                                $('#bugresult').attr('src', dataURL);
                                glitchEffect.BugBgVisible();


                            });



                        console.log("glitch end");

                    }

                    // });
                });
            },
            BugBgVisible: function() {
                $('#bugresult_wrap').addClass("v");
                var val = Math.round(Math.random() * 26);
                console.log(val);
                glitchEffect.BugStart(val);

            },
            BugStart: function(v) {


                $("#bugresult_pict").css({
                    'height': 0,
                    'width': 260
                });
                $("#bugresult_pict").attr('src', _prof_pict[v]);

                const tl = gsap.timeline();
                tl.to(_gif, {
                    duration: 3,
                    bottom: 0
                });
                tl.to('#bugresult_pict', {
                    duration: 0.5,
                    height: 200,
                    ease: 'power2.out'
                });
                tl.to('#bugresult_name', {
                    duration: 1,
                    delay: 1,
                    text: _prof_name[v],
                    ease: 'power2.in'
                });

                tl.to('#bugresult_message', {
                    duration: 5,
                    text: _prof_text[v],
                    ease: 'power2.in'
                });


                $("#bug_close").on("click", function() {
                    glitchEffect.Close();
                });
            },
            Close: function() {

                gsap.to($("#bugresult_wrap"), {
                    duration: 0.5,
                    top: "120%",
                    onComplete: glitchEffect.Reset
                });
            },
            Reset: function() {
                console.log("reset");
                $("#bugresult_wrap").removeClass("v");
                $("#bugresult_wrap").css({
                    top: 0
                });
                _gif.css({
                    bottom: "-300px"
                });
                $("#bugresult_name").text("");
                $("#bugresult_message").text("");
            }
        }
    })();

    //--------------------------------------------------
    //
    //  TableHint 表組みスクロールヒント
    //
    //--------------------------------------------------
    var TableHint = (function() {

        return {
            Init: function() {
                $(".scroll-hint").on("touchstart click", function() {
                    // $(".table-wrap").removeClass("scroll-hint");
                    // console.log("as");
                    TableHint.Close();
                });



            },
            Close: function() {
                $(".table-wrap").removeClass("scroll-hint");
            }
        }
    })();


    $(function() {

        TableHint.Init();
        ModalContents.Init();
        // ImageProtect.Init("/photo/");
        WindowDraggble.Init();
        TopMvFunc.Init();
        ContentsMore.Init();
        ContentsMore2.Init();
        SmoothScroll.Init();
        TopAnim.Init();
        TopicsMore.Init();
        PageTop.Init();
        HamburgerMenu.Init();

        // glitchEffect.Init();

        let spMenu = $("#spNews.windowmini");
        $(window).on("load", function() {
            gsap.to(spMenu, 0.2, {
                right: 0,
                delay: 0,
                ease: Power2.easeInOut
            });
        });


        // var event;
        // $('.goog-te-combo').change(function(e) {
        //   // console.log("change");

        //     if (navigator.userAgent.indexOf('iPhone') != -1) {
        //         event = e;
        //     } else {
        //         onChange(e);
        //     }
        // });
        // if (navigator.userAgent.indexOf('iPhone') != -1) {
        //     $('.goog-te-combo').focusout(function() {
        //       // console.log("focusout");
        //       if (event) {
        //             onChange(event);
        //         }
        //     });
        // }
        // function onChange(e){
        //   console.log(e);
        // }



        // const setFillHeight = () => {
        //   const vh = window.innerHeight * 0.01;
        //   console.log(vh);
        //   document.documentElement.style.setProperty('--vh', `${vh}px`);
        // }

        // // 画面のサイズ変動があった時に高さを再計算する
        // window.addEventListener('resize', setFillHeight);

        // // 初期化
        // setFillHeight();

        //css transition 初回オフ
        $(window).on('load', function() {
            $('body').removeClass('preload');
        });

        $(window).on('resize', function() {
            // winResize();
        });
        // $(window).on('load scroll touchmove resize', tabFix);

    });



    $('.ztmy-medal-slide').slick({
        dots: true,
        infinite: true,
        speed: 300,
        arrows: true,
        slidesToShow: 1,
        adaptiveHeight: true
    });




    //--------------------------------------------------
    //
    //  ContentsMore もっと見る
    //
    //--------------------------------------------------





})(jQuery);